import 'package:equatable/equatable.dart';

class ParsedFields extends Equatable {
  const ParsedFields({
    this.documentNumber,
    this.pinfl,
    this.birthDate,
    this.fromMrz = false,
  });

  static const empty = ParsedFields();

  final String? documentNumber;
  final String? pinfl;
  final DateTime? birthDate;
  final bool fromMrz;

  bool get isEmpty =>
      documentNumber == null && pinfl == null && birthDate == null;

  @override
  List<Object?> get props => [documentNumber, pinfl, birthDate, fromMrz];

  @override
  bool get stringify => true;
}
