import 'package:equatable/equatable.dart';

enum DocDataSource { mrz, visualZone }

class ScanResult extends Equatable {
  const ScanResult({
    required this.birthDate,
    required this.source,
    this.documentNumber,
    this.pinfl,
  }) : assert(documentNumber != null || pinfl != null);

  final String? documentNumber;
  final String? pinfl;
  final DateTime birthDate;
  final DocDataSource source;

  @override
  List<Object?> get props => [documentNumber, pinfl, birthDate, source];

  @override
  bool get stringify => true;
}
