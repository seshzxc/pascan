# passport_scanner

OCR-движок нативный для каждой платформы: **ML Kit Text Recognition на Android** (Kotlin) и **Apple Vision `VNRecognizeTextRequest` на iOS**. Дальше единый Dart-парсинг:

1. **MRZ (приоритет)** — TD3 (паспорт) и TD1 (ID-картa). Каждое поле валидируется чек-цифрами ICAO 9303. OCR-путаница `0 O`, `8 B`, `5 S`, `1 I` и т.д. исправляется позиционной нормализацией и подтверждается checksum, поэтому результат принимается с первого валидного кадра.
2. **Визуальная зона (fallback)** — лицевая сторона ID-карты: номер карты по паттерну `[A-Z]{2}\d{7}`, ПИНФЛ (14 цифр), дата рождения по лейблу `Date of birth / Tug'ilgan` или как самая ранняя прошедшая дата. Чек-цифр нет, поэтому результат принимается только после совпадения на `confirmationFrames` кадрах подряд.

На лицевой стороне ID-карты ПИНФЛ физически отсутствует — в этом случае `pinfl == null`, возвращается номер карты и дата рождения.

## Подключение

```yaml
dependencies:
  passport_scanner:
    path: ../passport_scanner
```

### Android

`android/app/build.gradle`: `minSdkVersion 21`.

`AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.CAMERA" />
```

### iOS

`ios/Podfile`: `platform :ios, '13.0'` или выше. GoogleMLKit-поды не подключаются — используется системный Vision, IPA не растёт.

`Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>Сканирование документа</string>
```

Запрос runtime-разрешения на камеру — ответственность приложения (например, `permission_handler`) до показа `PassportScannerView`.

## Использование

```dart
PassportScannerView(
  overlay: const ScanFrameOverlay(),
  onScanned: (result) {
    result.documentNumber;
    result.pinfl;
    result.birthDate;
    result.source;
    Navigator.of(context).pop(result);
  },
)
```

Либо через контроллер, если нужен свой UI:

```dart
final controller = PassportScannerController();
await controller.start();
final result = await controller.result;
await controller.dispose();
```

## Тесты

```bash
flutter test
```

Тесты покрывают реальные MRZ-вектора, коррекцию OCR-путаницы символов и fallback по визуальной зоне.

Android package: uz.passport_scanner мб надо поменять