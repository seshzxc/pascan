import Flutter
import Vision
import CoreVideo

public class PassportScannerPlugin: NSObject, FlutterPlugin, DocumentOcrApi {
    private let processingQueue = DispatchQueue(label: "uz.passport_scanner.ocr", qos: .userInitiated)

    public static func register(with registrar: FlutterPluginRegistrar) {
        let instance = PassportScannerPlugin()
        DocumentOcrApiSetup.setUp(binaryMessenger: registrar.messenger(), api: instance)
    }

    func recognize(frame: OcrFrame, completion: @escaping (Result<String?, Error>) -> Void) {
        let bytes = frame.bytes.data
        let width = Int(frame.width)
        let height = Int(frame.height)
        let bytesPerRow = Int(frame.bytesPerRow)
        let rotationDegrees = Int(frame.rotationDegrees)

        processingQueue.async { [weak self] in
            guard let self else { return }
            guard let pixelBuffer = self.makePixelBuffer(
                bytes: bytes,
                width: width,
                height: height,
                bytesPerRow: bytesPerRow
            ) else {
                completion(.failure(PigeonError(
                    code: "buffer_failed",
                    message: "Cannot create pixel buffer",
                    details: nil
                )))
                return
            }
            self.runVision(
                pixelBuffer: pixelBuffer,
                orientation: Self.orientation(fromDegrees: rotationDegrees),
                completion: completion
            )
        }
    }

    private func runVision(
        pixelBuffer: CVPixelBuffer,
        orientation: CGImagePropertyOrientation,
        completion: @escaping (Result<String?, Error>) -> Void
    ) {
        let request = VNRecognizeTextRequest { request, error in
            if let error {
                completion(.failure(PigeonError(
                    code: "ocr_failed",
                    message: error.localizedDescription,
                    details: nil
                )))
                return
            }
            let observations = request.results as? [VNRecognizedTextObservation] ?? []
            let text = observations
                .compactMap { $0.topCandidates(1).first?.string }
                .joined(separator: "\n")
            completion(.success(text))
        }
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        request.recognitionLanguages = ["en-US"]

        let handler = VNImageRequestHandler(
            cvPixelBuffer: pixelBuffer,
            orientation: orientation,
            options: [:]
        )
        do {
            try handler.perform([request])
        } catch {
            completion(.failure(PigeonError(
                code: "ocr_failed",
                message: error.localizedDescription,
                details: nil
            )))
        }
    }

    private func makePixelBuffer(
        bytes: Data,
        width: Int,
        height: Int,
        bytesPerRow: Int
    ) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
        ]
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_32BGRA,
            attributes as CFDictionary,
            &pixelBuffer
        )
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else { return nil }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let destination = CVPixelBufferGetBaseAddress(buffer) else { return nil }

        let destinationBytesPerRow = CVPixelBufferGetBytesPerRow(buffer)
        let copyBytesPerRow = min(bytesPerRow, destinationBytesPerRow)

        bytes.withUnsafeBytes { (source: UnsafeRawBufferPointer) in
            guard let sourceBase = source.baseAddress else { return }
            for row in 0..<height {
                let sourceOffset = row * bytesPerRow
                guard sourceOffset + copyBytesPerRow <= bytes.count else { break }
                memcpy(
                    destination.advanced(by: row * destinationBytesPerRow),
                    sourceBase.advanced(by: sourceOffset),
                    copyBytesPerRow
                )
            }
        }
        return buffer
    }

    private static func orientation(fromDegrees degrees: Int) -> CGImagePropertyOrientation {
        switch degrees {
        case 90: return .right
        case 180: return .down
        case 270: return .left
        default: return .up
        }
    }
}
