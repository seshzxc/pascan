import Flutter
import Vision
import CoreVideo

public class PassportScannerPlugin: NSObject, FlutterPlugin {
    private let processingQueue = DispatchQueue(label: "uz.passport_scanner.ocr", qos: .userInitiated)

    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(
            name: "passport_scanner",
            binaryMessenger: registrar.messenger()
        )
        registrar.addMethodCallDelegate(PassportScannerPlugin(), channel: channel)
    }

    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        guard call.method == "recognize" else {
            result(FlutterMethodNotImplemented)
            return
        }
        guard
            let args = call.arguments as? [String: Any],
            let typedBytes = args["bytes"] as? FlutterStandardTypedData,
            let width = args["width"] as? Int,
            let height = args["height"] as? Int,
            let bytesPerRow = args["bytesPerRow"] as? Int,
            let rotationDegrees = args["rotationDegrees"] as? Int
        else {
            result(FlutterError(code: "invalid_arguments", message: "Missing frame arguments", details: nil))
            return
        }

        let bytes = typedBytes.data
        processingQueue.async { [weak self] in
            guard let self else { return }
            guard let pixelBuffer = self.makePixelBuffer(
                bytes: bytes,
                width: width,
                height: height,
                bytesPerRow: bytesPerRow
            ) else {
                DispatchQueue.main.async {
                    result(FlutterError(code: "buffer_failed", message: "Cannot create pixel buffer", details: nil))
                }
                return
            }
            self.recognize(
                pixelBuffer: pixelBuffer,
                orientation: Self.orientation(fromDegrees: rotationDegrees),
                result: result
            )
        }
    }

    private func recognize(
        pixelBuffer: CVPixelBuffer,
        orientation: CGImagePropertyOrientation,
        result: @escaping FlutterResult
    ) {
        let request = VNRecognizeTextRequest { request, error in
            if let error {
                DispatchQueue.main.async {
                    result(FlutterError(code: "ocr_failed", message: error.localizedDescription, details: nil))
                }
                return
            }
            let observations = request.results as? [VNRecognizedTextObservation] ?? []
            let text = observations
                .compactMap { $0.topCandidates(1).first?.string }
                .joined(separator: "\n")
            DispatchQueue.main.async {
                result(text)
            }
        }
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        request.recognitionLanguages = ["en-US"]

        let handler = VNImageRequestHandler(
            cvPixelBuffer: pixelBuffer,
            orientation: orientation,
            options: [:]
        )
        do {
            try handler.perform([request])
        } catch {
            DispatchQueue.main.async {
                result(FlutterError(code: "ocr_failed", message: error.localizedDescription, details: nil))
            }
        }
    }

    private func makePixelBuffer(
        bytes: Data,
        width: Int,
        height: Int,
        bytesPerRow: Int
    ) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
        ]
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_32BGRA,
            attributes as CFDictionary,
            &pixelBuffer
        )
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else { return nil }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let destination = CVPixelBufferGetBaseAddress(buffer) else { return nil }

        let destinationBytesPerRow = CVPixelBufferGetBytesPerRow(buffer)
        let copyBytesPerRow = min(bytesPerRow, destinationBytesPerRow)

        bytes.withUnsafeBytes { (source: UnsafeRawBufferPointer) in
            guard let sourceBase = source.baseAddress else { return }
            for row in 0..<height {
                let sourceOffset = row * bytesPerRow
                guard sourceOffset + copyBytesPerRow <= bytes.count else { break }
                memcpy(
                    destination.advanced(by: row * destinationBytesPerRow),
                    sourceBase.advanced(by: sourceOffset),
                    copyBytesPerRow
                )
            }
        }
        return buffer
    }

    private static func orientation(fromDegrees degrees: Int) -> CGImagePropertyOrientation {
        switch degrees {
        case 90: return .right
        case 180: return .down
        case 270: return .left
        default: return .up
        }
    }
}
