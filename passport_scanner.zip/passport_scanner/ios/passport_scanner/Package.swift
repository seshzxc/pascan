// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "passport_scanner",
    platforms: [
        .iOS("13.0"),
    ],
    products: [
        .library(name: "passport-scanner", targets: ["passport_scanner"]),
    ],
    dependencies: [
        .package(name: "FlutterFramework", path: "../FlutterFramework"),
    ],
    targets: [
        .target(
            name: "passport_scanner",
            dependencies: [
                .product(name: "FlutterFramework", package: "FlutterFramework"),
            ]
        ),
    ]
)
