Pod::Spec.new do |s|
  s.name             = 'passport_scanner'
  s.version          = '0.0.1'
  s.summary          = 'Document scanner backed by Apple Vision'
  s.description      = 'Live camera OCR for passports and ID cards using VNRecognizeTextRequest.'
  s.homepage         = 'https://example.com'
  s.license          = { :type => 'MIT' }
  s.author           = { 'passport_scanner' => 'dev@example.com' }
  s.source           = { :path => '.' }
  s.source_files     = 'passport_scanner/Sources/passport_scanner/**/*.swift'
  s.dependency 'Flutter'
  s.platform         = :ios, '13.0'
  s.frameworks       = 'Vision', 'CoreVideo'
  s.swift_version    = '5.0'
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES' }
end
