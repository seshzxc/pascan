package uz.passport_scanner

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import io.flutter.embedding.engine.plugins.FlutterPlugin

class PassportScannerPlugin : FlutterPlugin, DocumentOcrApi {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        DocumentOcrApi.setUp(binding.binaryMessenger, this)
    }

    override fun recognize(frame: OcrFrame, callback: (Result<String?>) -> Unit) {
        val image = InputImage.fromByteArray(
            frame.bytes,
            frame.width.toInt(),
            frame.height.toInt(),
            frame.rotationDegrees.toInt(),
            InputImage.IMAGE_FORMAT_NV21,
        )
        recognizer.process(image)
            .addOnSuccessListener { callback(Result.success(it.text)) }
            .addOnFailureListener { callback(Result.failure(it)) }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        DocumentOcrApi.setUp(binding.binaryMessenger, null)
        recognizer.close()
    }
}
