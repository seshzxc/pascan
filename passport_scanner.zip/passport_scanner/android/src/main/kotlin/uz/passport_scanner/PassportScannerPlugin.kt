package uz.passport_scanner

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result

class PassportScannerPlugin : FlutterPlugin, MethodCallHandler {
    private lateinit var channel: MethodChannel
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel = MethodChannel(binding.binaryMessenger, "passport_scanner")
        channel.setMethodCallHandler(this)
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        if (call.method != "recognize") {
            result.notImplemented()
            return
        }
        val bytes = call.argument<ByteArray>("bytes")
        val width = call.argument<Int>("width")
        val height = call.argument<Int>("height")
        val rotationDegrees = call.argument<Int>("rotationDegrees")
        if (bytes == null || width == null || height == null || rotationDegrees == null) {
            result.error("invalid_arguments", "Missing frame arguments", null)
            return
        }

        val image = InputImage.fromByteArray(
            bytes,
            width,
            height,
            rotationDegrees,
            InputImage.IMAGE_FORMAT_NV21,
        )
        recognizer.process(image)
            .addOnSuccessListener { result.success(it.text) }
            .addOnFailureListener { result.error("ocr_failed", it.message, null) }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        recognizer.close()
    }
}
