enum DocDataSource { mrz, visualZone }

class ScanResult {
  const ScanResult({
    required this.birthDate,
    required this.source,
    this.documentNumber,
    this.pinfl,
  }) : assert(documentNumber != null || pinfl != null);

  final String? documentNumber;
  final String? pinfl;
  final DateTime birthDate;
  final DocDataSource source;

  @override
  bool operator ==(Object other) =>
      other is ScanResult &&
      other.documentNumber == documentNumber &&
      other.pinfl == pinfl &&
      other.birthDate == birthDate &&
      other.source == source;

  @override
  int get hashCode => Object.hash(documentNumber, pinfl, birthDate, source);

  @override
  String toString() =>
      'ScanResult(documentNumber: $documentNumber, pinfl: $pinfl, '
      'birthDate: $birthDate, source: $source)';
}
