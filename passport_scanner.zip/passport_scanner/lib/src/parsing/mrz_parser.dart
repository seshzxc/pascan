import 'package:passport_scanner/src/models/scan_result.dart';
import 'ocr_normalizer.dart';

abstract final class MrzParser {
  static final _documentNumberPattern = RegExp(r'^[A-Z]{2}\d{7}$');
  static final _pinflPattern = RegExp(r'^\d{14}$');
  static final _sixDigitsPattern = RegExp(r'^\d{6}$');

  static ScanResult? parse(String text) {
    final lines = text
        .toUpperCase()
        .split('\n')
        .map((l) => l.replaceAll(RegExp(r'\s'), ''))
        .toList();

    for (final line in lines.where((l) => l.length == 44)) {
      final result = _parseTd3Line2(line);
      if (result != null) return result;
    }

    final td1Lines = lines.where((l) => l.length == 30).toList();
    for (final first in td1Lines) {
      for (final second in td1Lines) {
        if (identical(first, second)) continue;
        final result = _parseTd1(first, second);
        if (result != null) return result;
      }
    }
    return null;
  }

  static ScanResult? _parseTd3Line2(String line) {
    final documentNumber = _documentNumber(line.substring(0, 9), line[9]);
    final birthDate = _date(line.substring(13, 19), line[19]);
    if (documentNumber == null || birthDate == null) return null;

    final pinfl = _validatedPinfl(line.substring(28, 42), line[42]);
    return ScanResult(
      documentNumber: documentNumber,
      pinfl: pinfl,
      birthDate: birthDate,
      source: DocDataSource.mrz,
    );
  }

  static ScanResult? _parseTd1(String line1, String line2) {
    final documentNumber = _documentNumber(line1.substring(5, 14), line1[14]);
    final birthDate = _date(line2.substring(0, 6), line2[6]);
    if (documentNumber == null || birthDate == null) return null;

    final optional = OcrNormalizer.digits(
      line1.substring(15).replaceAll('<', ''),
    );
    final pinfl = _pinflPattern.hasMatch(optional) ? optional : null;
    return ScanResult(
      documentNumber: documentNumber,
      pinfl: pinfl,
      birthDate: birthDate,
      source: DocDataSource.mrz,
    );
  }

  static String? _documentNumber(String raw, String checkChar) {
    final normalized = OcrNormalizer.letters(raw.substring(0, 2)) +
        OcrNormalizer.digits(raw.substring(2));
    if (!_documentNumberPattern.hasMatch(normalized)) return null;
    if (!_checkValid(normalized, checkChar)) return null;
    return normalized;
  }

  static DateTime? _date(String raw, String checkChar) {
    final normalized = OcrNormalizer.digits(raw);
    if (!_sixDigitsPattern.hasMatch(normalized)) return null;
    if (!_checkValid(normalized, checkChar)) return null;

    final yy = int.parse(normalized.substring(0, 2));
    final month = int.parse(normalized.substring(2, 4));
    final day = int.parse(normalized.substring(4, 6));
    var year = 2000 + yy;
    if (year > DateTime.now().year) year -= 100;

    final date = DateTime(year, month, day);
    if (date.month != month || date.day != day) return null;
    return date;
  }

  static String? _validatedPinfl(String raw, String checkChar) {
    final normalized = OcrNormalizer.digits(raw.replaceAll('<', ''));
    if (!_pinflPattern.hasMatch(normalized)) return null;
    if (!_checkValid(normalized, checkChar)) return null;
    return normalized;
  }

  static bool _checkValid(String field, String checkChar) {
    final expected = int.tryParse(OcrNormalizer.digits(checkChar));
    final computed = checkDigit(field);
    return expected != null && computed != null && computed == expected;
  }

  static int? checkDigit(String field) {
    const weights = [7, 3, 1];
    var sum = 0;
    for (var i = 0; i < field.length; i++) {
      final code = field.codeUnitAt(i);
      final int value;
      if (code >= 0x30 && code <= 0x39) {
        value = code - 0x30;
      } else if (code >= 0x41 && code <= 0x5A) {
        value = code - 0x37;
      } else if (code == 0x3C) {
        value = 0;
      } else {
        return null;
      }
      sum += value * weights[i % 3];
    }
    return sum % 10;
  }
}
