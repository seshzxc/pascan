abstract final class OcrNormalizer {
  static const _toDigit = <String, String>{
    'O': '0',
    'Q': '0',
    'D': '0',
    'I': '1',
    'L': '1',
    'Z': '2',
    'S': '5',
    'G': '6',
    'B': '8',
  };

  static const _toLetter = <String, String>{
    '0': 'O',
    '1': 'I',
    '2': 'Z',
    '5': 'S',
    '6': 'G',
    '8': 'B',
  };

  static String digits(String input) =>
      input.split('').map((c) => _toDigit[c] ?? c).join();

  static String letters(String input) =>
      input.split('').map((c) => _toLetter[c] ?? c).join();
}
