import 'package:passport_scanner/src/models/scan_result.dart';
import 'mrz_parser.dart';
import 'visual_zone_parser.dart';

abstract final class DocumentParser {
  static ScanResult? parse(String recognizedText) =>
      MrzParser.parse(recognizedText) ?? VisualZoneParser.parse(recognizedText);
}
