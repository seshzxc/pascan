import 'package:passport_scanner/src/models/scan_result.dart';
import 'ocr_normalizer.dart';

abstract final class VisualZoneParser {
  static final _tokenSplitter = RegExp(r'[^A-Z0-9]+');
  static final _documentNumberPattern = RegExp(r'^[A-Z]{2}\d{7}$');
  static final _pinflPattern = RegExp(r'^\d{14}$');
  static final _datePattern = RegExp(
    r'([0-9OQDILZSGB]{2})[.,\t ]+([0-9OQDILZSGB]{2})[.,\t ]*([0-9OQDILZSGB]{4})',
  );
  static final _birthLabelPattern = RegExp(r'BIRTH|TUG');

  static ScanResult? parse(String text) {
    final upper = text.toUpperCase();
    final documentNumber = _findDocumentNumber(upper);
    final pinfl = _findPinfl(upper);
    final birthDate = _findBirthDate(upper);

    if (birthDate == null || (documentNumber == null && pinfl == null)) {
      return null;
    }
    return ScanResult(
      documentNumber: documentNumber,
      pinfl: pinfl,
      birthDate: birthDate,
      source: DocDataSource.visualZone,
    );
  }

  static String? _findDocumentNumber(String text) {
    for (final token in _tokens(text)) {
      if (token.length != 9) continue;
      final candidate = OcrNormalizer.letters(token.substring(0, 2)) +
          OcrNormalizer.digits(token.substring(2));
      if (_documentNumberPattern.hasMatch(candidate)) return candidate;
    }
    return null;
  }

  static String? _findPinfl(String text) {
    for (final token in _tokens(text)) {
      if (token.length != 14) continue;
      final candidate = OcrNormalizer.digits(token);
      if (_pinflPattern.hasMatch(candidate)) return candidate;
    }
    return null;
  }

  static Iterable<String> _tokens(String text) =>
      text.split(_tokenSplitter).where((t) => t.isNotEmpty);

  static DateTime? _findBirthDate(String text) {
    final lines = text.split('\n');
    for (var i = 0; i < lines.length; i++) {
      if (!_birthLabelPattern.hasMatch(lines[i])) continue;
      final sameLine = _firstDateIn(lines[i]);
      if (sameLine != null) return sameLine;
      if (i + 1 < lines.length) {
        final nextLine = _firstDateIn(lines[i + 1]);
        if (nextLine != null) return nextLine;
      }
    }

    final now = DateTime.now();
    final past = _allDatesIn(text).where((d) => !d.isAfter(now)).toList()
      ..sort();
    return past.isEmpty ? null : past.first;
  }

  static DateTime? _firstDateIn(String line) {
    for (final date in _allDatesIn(line)) {
      return date;
    }
    return null;
  }

  static Iterable<DateTime> _allDatesIn(String text) sync* {
    for (final match in _datePattern.allMatches(text)) {
      final day = int.parse(OcrNormalizer.digits(match.group(1)!));
      final month = int.parse(OcrNormalizer.digits(match.group(2)!));
      final yearRaw = OcrNormalizer.digits(match.group(3)!);
      final year = _normalizeYear(yearRaw);
      if (year == null || month < 1 || month > 12 || day < 1 || day > 31) {
        continue;
      }
      final date = DateTime(year, month, day);
      if (date.month != month || date.day != day) continue;
      yield date;
    }
  }

  static int? _normalizeYear(String raw) {
    final year = int.parse(raw);
    return year >= 1900 && year <= 2100 ? year : null;
  }
}
