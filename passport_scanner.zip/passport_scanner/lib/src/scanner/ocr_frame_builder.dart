import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/services.dart';

import 'messages.g.dart';

abstract final class OcrFrameBuilder {
  static const _orientationDegrees = <DeviceOrientation, int>{
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  static OcrFrame? build({
    required CameraImage image,
    required CameraDescription camera,
    required DeviceOrientation deviceOrientation,
  }) {
    if (image.planes.length != 1) return null;
    final rotation = _rotationDegrees(camera, deviceOrientation);
    if (rotation == null) return null;

    final plane = image.planes.first;
    return OcrFrame(
      bytes: plane.bytes,
      width: image.width,
      height: image.height,
      bytesPerRow: plane.bytesPerRow,
      rotationDegrees: rotation,
    );
  }

  static int? _rotationDegrees(
    CameraDescription camera,
    DeviceOrientation deviceOrientation,
  ) {
    if (Platform.isIOS) return camera.sensorOrientation;
    final compensation = _orientationDegrees[deviceOrientation];
    if (compensation == null) return null;
    return camera.lensDirection == CameraLensDirection.front
        ? (camera.sensorOrientation + compensation) % 360
        : (camera.sensorOrientation - compensation + 360) % 360;
  }
}
