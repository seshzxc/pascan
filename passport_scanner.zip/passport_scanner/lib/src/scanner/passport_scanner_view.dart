import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

import '../models/scan_result.dart';
import 'passport_scanner_controller.dart';

class PassportScannerView extends StatefulWidget {
  const PassportScannerView({
    super.key,
    required this.onScanned,
    this.controller,
    this.overlay,
  });

  final ValueChanged<ScanResult> onScanned;
  final PassportScannerController? controller;
  final Widget? overlay;

  @override
  State<PassportScannerView> createState() => _PassportScannerViewState();
}

class _PassportScannerViewState extends State<PassportScannerView>
    with WidgetsBindingObserver {
  late final PassportScannerController _controller =
      widget.controller ?? PassportScannerController();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  Future<void> _start() async {
    await _controller.start();
    if (!mounted) return;
    setState(() => _ready = true);
    final result = await _controller.result;
    if (mounted) widget.onScanned(result);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final camera = _controller.camera;
    if (camera == null || !camera.value.isInitialized) return;
    switch (state) {
      case AppLifecycleState.inactive:
        camera.pausePreview();
      case AppLifecycleState.resumed:
        camera.resumePreview();
      default:
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (widget.controller == null) _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final camera = _controller.camera;
    if (!_ready || camera == null) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator()),
      );
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        CameraPreview(camera),
        if (widget.overlay != null) widget.overlay!,
      ],
    );
  }
}
