import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';

import '../models/scan_result.dart';
import '../parsing/document_parser.dart';
import 'document_ocr.dart';
import 'frame_payload.dart';

class PassportScannerController {
  PassportScannerController({
    this.confirmationFrames = 2,
    this.resolution = ResolutionPreset.high,
    this.debugLogging = false,
  });

  final int confirmationFrames;
  final ResolutionPreset resolution;
  final bool debugLogging;

  final _ocr = DocumentOcr();
  final _completer = Completer<ScanResult>();

  CameraController? _camera;
  bool _processing = false;
  bool _disposed = false;
  ScanResult? _pending;
  int _pendingCount = 0;

  CameraController? get camera => _camera;

  Future<ScanResult> get result => _completer.future;

  Future<void> start() async {
    final cameras = await availableCameras();
    final description = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first,
    );
    final camera = CameraController(
      description,
      resolution,
      enableAudio: false,
      imageFormatGroup: Platform.isAndroid
          ? ImageFormatGroup.nv21
          : ImageFormatGroup.bgra8888,
    );
    _camera = camera;
    await camera.initialize();
    if (_disposed) return;
    await camera.startImageStream(_onFrame);
  }

  Future<void> _onFrame(CameraImage image) async {
    if (_processing || _completer.isCompleted || _disposed) return;
    final camera = _camera;
    if (camera == null) return;

    _processing = true;
    try {
      final payload = FramePayload.from(
        image: image,
        camera: camera.description,
        deviceOrientation: camera.value.deviceOrientation,
      );
      if (payload == null) return;

      final text = await _ocr.recognize(payload);
      if (text == null || text.isEmpty) return;

      final parsed = DocumentParser.parse(text);
      if (debugLogging) {
        debugPrint('=== PASSPORT_SCANNER OCR ===\n$text');
        debugPrint('=== PARSED: $parsed ===');
      }
      if (parsed != null) _onParsed(parsed);
    } finally {
      _processing = false;
    }
  }

  void _onParsed(ScanResult parsed) {
    if (parsed.source == DocDataSource.mrz) {
      _complete(parsed);
      return;
    }
    if (parsed == _pending) {
      _pendingCount++;
    } else if (_pending != null &&
        parsed.documentNumber == _pending!.documentNumber &&
        parsed.pinfl == _pending!.pinfl &&
        parsed.birthDate == _pending!.birthDate) {
      _pendingCount++;
    } else {
      _pending = parsed;
      _pendingCount = 1;
    }
    if (_pendingCount >= confirmationFrames) _complete(parsed);
  }

  void _complete(ScanResult result) {
    if (_completer.isCompleted) return;
    _completer.complete(result);
    final camera = _camera;
    if (camera != null && camera.value.isStreamingImages) {
      unawaited(camera.stopImageStream());
    }
  }

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    final camera = _camera;
    _camera = null;
    if (camera != null) {
      if (camera.value.isStreamingImages) await camera.stopImageStream();
      await camera.dispose();
    }
  }
}
