import 'package:flutter/services.dart';

import 'frame_payload.dart';

class DocumentOcr {
  static const _channel = MethodChannel('passport_scanner');

  Future<String?> recognize(FramePayload payload) async {
    try {
      return await _channel.invokeMethod<String>('recognize', payload.toMap());
    } on PlatformException {
      return null;
    }
  }
}
