import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/services.dart';

class FramePayload {
  const FramePayload._({
    required this.bytes,
    required this.width,
    required this.height,
    required this.bytesPerRow,
    required this.rotationDegrees,
  });

  final Uint8List bytes;
  final int width;
  final int height;
  final int bytesPerRow;
  final int rotationDegrees;

  static const _orientationDegrees = <DeviceOrientation, int>{
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  static FramePayload? from({
    required CameraImage image,
    required CameraDescription camera,
    required DeviceOrientation deviceOrientation,
  }) {
    if (image.planes.length != 1) return null;
    final rotation = _rotationDegrees(camera, deviceOrientation);
    if (rotation == null) return null;

    final plane = image.planes.first;
    return FramePayload._(
      bytes: plane.bytes,
      width: image.width,
      height: image.height,
      bytesPerRow: plane.bytesPerRow,
      rotationDegrees: rotation,
    );
  }

  static int? _rotationDegrees(
    CameraDescription camera,
    DeviceOrientation deviceOrientation,
  ) {
    if (Platform.isIOS) return camera.sensorOrientation;
    final compensation = _orientationDegrees[deviceOrientation];
    if (compensation == null) return null;
    return camera.lensDirection == CameraLensDirection.front
        ? (camera.sensorOrientation + compensation) % 360
        : (camera.sensorOrientation - compensation + 360) % 360;
  }

  Map<String, Object> toMap() => {
        'bytes': bytes,
        'width': width,
        'height': height,
        'bytesPerRow': bytesPerRow,
        'rotationDegrees': rotationDegrees,
      };
}
