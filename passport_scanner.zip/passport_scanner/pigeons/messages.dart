import 'package:pigeon/pigeon.dart';

@ConfigurePigeon(
  PigeonOptions(
    dartOut: 'lib/src/scanner/messages.g.dart',
    kotlinOut: 'android/src/main/kotlin/uz/passport_scanner/Messages.g.kt',
    kotlinOptions: KotlinOptions(package: 'uz.passport_scanner'),
    swiftOut: 'ios/passport_scanner/Sources/passport_scanner/Messages.g.swift',
    dartPackageName: 'passport_scanner',
  ),
)
class OcrFrame {
  OcrFrame({
    required this.bytes,
    required this.width,
    required this.height,
    required this.bytesPerRow,
    required this.rotationDegrees,
  });

  final Uint8List bytes;
  final int width;
  final int height;
  final int bytesPerRow;
  final int rotationDegrees;
}

@HostApi()
abstract class DocumentOcrApi {
  @async
  String? recognize(OcrFrame frame);
}
