# passport_scanner

Live-сканер паспортов и ID-карт. Извлекает номер документа (`AB1234567`), ПИНФЛ и дату рождения из потока камеры.

## Как работает

Камера и OCR живут в нативе (CameraX + ML Kit на Android, AVCaptureSession + Vision на iOS). В Dart уходят только id текстуры и распознанный текст — кадры через channel не копируются.

Парсинг единый в Dart:

1. **MRZ (приоритет)** — TD3/TD1, каждое поле валидируется чек-цифрами ICAO 9303. OCR-путаница (`0 O`, `8 B`, `5 S`, `1 I`) исправляется позиционной нормализацией. Принимается с первого валидного кадра.
2. **Визуальная зона (fallback)** — лицевая сторона ID: номер `[A-Z]{2}\d{7}`, ПИНФЛ (14 цифр), дата рождения. Без чек-цифр, поэтому нужно совпадение на `fieldConfirmations` кадрах.

На лицевой стороне ID ПИНФЛ отсутствует — тогда `pinfl == null`.

## Превью

Заполняет весь виджет (`BoxFit.cover`, излишки кропаются). Разрешение: приоритет 16:9, 720p

## Использование

```dart
const roi = Rect.fromLTRB(0.05, 0.28, 0.95, 0.72);

PassportScannerView(
  controller: PassportScannerController(roi: roi),
  overlay: const ScanFrameOverlay(roi: roi),
  onScanned: (result) => Navigator.of(context).pop(result),
)
```

Либо через контроллер со своим UI:

```dart
final controller = PassportScannerController();
await controller.start();
final result = await controller.result;
await controller.dispose();
```

Lifecycle приложения view обрабатывает сам (pause/resume). При уходе с экрана камера освобождается в `dispose`; при внешнем контроллере вызывай `controller.dispose()` сам.

## ROI

По умолчанию выключен — анализируется весь кадр. Координаты нормализованы (0..1) в системе **кадра**. `roi` — только фильтр распознавания, рамку рисует `overlay`; если одинаковые передаются в один `Rect`, тогда они совпадают при любом кропе.

## Настройка платформ

**Android** — `minSdkVersion 21`, в манифест приложения:

```xml
<uses-permission android:name="android.permission.CAMERA" />
```

**iOS** — `platform :ios, '13.0'`, GoogleMLKit-поды не подключаются (системный Vision). В `Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>Сканирование документа</string>
```

Runtime-запрос разрешения камеры — ответственность приложения до показа `PassportScannerView`.

## Телеметрия ML Kit (Android)

ML Kit шлёт события на `firebaselogging.googleapis.com`. Отключается в манифесте **приложения** (`xmlns:tools` обязателен):

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">
    <application>
        <service
            android:name="com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService"
            tools:node="remove" />
    </application>
</manifest>
```

Не зашито в пакет: сервис общий с Firebase Analytics/Crashlytics — удаление сломало бы их телеметрию. Распознавание от сети не зависит.

## Тесты

```bash
flutter test
```

Покрывают MRZ-вектора, коррекцию OCR-путаницы и fallback по визуальной зоне.
