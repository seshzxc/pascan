import 'package:flutter_test/flutter_test.dart';
import 'package:passport_scanner/passport_scanner.dart';

void main() {
  group('MRZ TD3 (passport)', () {
    const validLine2 = 'FA23299512UZB9604249M31031193240496692003648';

    test('normalizes Cyrillic homoglyphs in MRZ line', () {
      const line2 =
          'F\u041023299512UZB9604249M31031193240496692003648';
      final result = DocumentParser.parse(line2);
      expect(result, isNotNull);
      expect(result!.documentNumber, 'FA2329951');
      expect(result.birthDate, DateTime(1996, 4, 24));
    });

    test('parses valid line', () {
      final result = DocumentParser.parse(
        'P<UZBAZAMOV<<ABBOSJON<SOLIJON<UGLI<<<<<<<<<<\n$validLine2',
      );
      expect(result, isNotNull);
      expect(result!.documentNumber, 'FA2329951');
      expect(result.pinfl, '32404966920036');
      expect(result.birthDate, DateTime(1996, 4, 24));
      expect(result.source, DocDataSource.mrz);
    });

    test('recovers from O/0 and S/5 confusion via check digits', () {
      const corrupted = 'FA23299S12UZB96O4249M31031193240496692003648';
      final result = DocumentParser.parse(corrupted);
      expect(result, isNotNull);
      expect(result!.documentNumber, 'FA2329951');
      expect(result.birthDate, DateTime(1996, 4, 24));
    });

    test('rejects line with failing check digit', () {
      const broken = 'FA23299522UZB9604249M31031193240496692003648';
      expect(DocumentParser.parse(broken), isNull);
    });

    test('tolerates spaces inside MRZ line', () {
      final result =
          DocumentParser.parse('FA2329951 2UZB960424 9M31031193240496692003648');
      expect(result?.documentNumber, 'FA2329951');
    });
  });

  group('MRZ TD1 (ID card back)', () {
    const line1 = 'I<UZBAD1663506432404966920036<';
    const line2 = '6708124M3208151UZB<<<<<<<<<<<0';

    test('parses document number, pinfl and birth date', () {
      final result = DocumentParser.parse('$line1\n$line2\nGARBAGE');
      expect(result, isNotNull);
      expect(result!.documentNumber, 'AD1663506');
      expect(result.pinfl, '32404966920036');
      expect(result.birthDate, DateTime(1967, 8, 12));
      expect(result.source, DocDataSource.mrz);
    });

    test('parses lines in reversed order', () {
      final result = DocumentParser.parse('$line2\n$line1');
      expect(result?.documentNumber, 'AD1663506');
    });
  });

  group('Visual zone (ID card front)', () {
    const cardText = "O'ZBEKISTON RESPUBLIKASI\n"
        'SHAXS GUVOHNOMASI\n'
        'YUNUSOV\nMAKSUD\nMANSUROVICH\n'
        "Tug'ilgan sanasi / Date of birth\n"
        '12.08.1967\n'
        '16.08.2022\n15.08.2032\n'
        "ERKAK\nO'ZBEKISTON\nAD1663506";

    test('extracts card number and birth date by label', () {
      final result = DocumentParser.parse(cardText);
      expect(result, isNotNull);
      expect(result!.documentNumber, 'AD1663506');
      expect(result.pinfl, isNull);
      expect(result.birthDate, DateTime(1967, 8, 12));
      expect(result.source, DocDataSource.visualZone);
    });

    test('recovers document number and date from OCR confusion', () {
      const corrupted = 'Date of birth\nI2.O8.1967\nADI663SO6';
      final result = DocumentParser.parse(corrupted);
      expect(result, isNotNull);
      expect(result!.documentNumber, 'AD1663506');
      expect(result.birthDate, DateTime(1967, 8, 12));
    });

    test('falls back to earliest past date without label', () {
      const text = 'AD1663506\n16.08.2022\n12.08.1967\n15.08.2032';
      final result = DocumentParser.parse(text);
      expect(result?.birthDate, DateTime(1967, 8, 12));
    });

    test('extracts pinfl alone', () {
      const text = 'Date of birth 24.04.1996\n32404966920036';
      final result = DocumentParser.parse(text);
      expect(result, isNotNull);
      expect(result!.documentNumber, isNull);
      expect(result.pinfl, '32404966920036');
    });

    test('returns null when only date is present', () {
      expect(DocumentParser.parse('Date of birth 24.04.1996'), isNull);
    });

    test('normalizes Cyrillic homoglyphs in document number', () {
      const text = 'Date of birth\n12.08.1967\n\u0410D1663506';
      final result = DocumentParser.parse(text);
      expect(result?.documentNumber, 'AD1663506');
    });

    test('parses dirty OCR with missing dots in date', () {
      const text = 'ZAMOV\nAB80SJON\nSOLIJON 00L\nERKAK\n'
          '24.041996\nZBEKISTON\n16.10 2024\nAD9033984\n15.10.2034';
      final result = DocumentParser.parse(text);
      expect(result, isNotNull);
      expect(result!.documentNumber, 'AD9033984');
      expect(result.birthDate, DateTime(1996, 4, 24));
    });

    test('parses date with dropped middle dot', () {
      const text = 'AD9033984\n24.041996\n16.10 2024';
      final result = DocumentParser.parse(text);
      expect(result?.birthDate, DateTime(1996, 4, 24));
    });
  });
}
