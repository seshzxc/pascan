abstract final class OcrNormalizer {
  static const _toDigit = <String, String>{
    'O': '0',
    'Q': '0',
    'D': '0',
    'I': '1',
    'L': '1',
    'Z': '2',
    'S': '5',
    'G': '6',
    'B': '8',
  };

  static const _toLetter = <String, String>{
    '0': 'O',
    '1': 'I',
    '2': 'Z',
    '5': 'S',
    '6': 'G',
    '8': 'B',
  };

  static const _cyrillicToLatin = <String, String>{
    '\u0410': 'A',
    '\u0412': 'B',
    '\u0415': 'E',
    '\u041A': 'K',
    '\u041C': 'M',
    '\u041D': 'H',
    '\u041E': 'O',
    '\u0420': 'P',
    '\u0421': 'C',
    '\u0422': 'T',
    '\u0423': 'Y',
    '\u0425': 'X',
    '\u0406': 'I',
    '\u0408': 'J',
    '\u0405': 'S',
    '\u04AE': 'Y',
    '\u0396': 'Z',
    '\u039A': 'K',
    '\u039C': 'M',
    '\u039D': 'N',
    '\u039F': 'O',
    '\u03A1': 'P',
    '\u03A4': 'T',
    '\u0391': 'A',
    '\u0392': 'B',
    '\u0395': 'E',
    '\u0397': 'H',
    '\u0399': 'I',
    '\u03A5': 'Y',
    '\u03A7': 'X',
  };

  static String latinize(String input) =>
      input.split('').map((c) => _cyrillicToLatin[c] ?? c).join();

  static String digits(String input) =>
      input.split('').map((c) => _toDigit[c] ?? c).join();

  static String letters(String input) =>
      input.split('').map((c) => _toLetter[c] ?? c).join();
}
