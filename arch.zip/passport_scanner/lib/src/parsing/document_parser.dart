import '../models/parsed_fields.dart';
import '../models/scan_result.dart';
import 'mrz_parser.dart';
import 'ocr_normalizer.dart';
import 'visual_zone_parser.dart';

abstract final class DocumentParser {
  static ScanResult? parse(String recognizedText) {
    final text = OcrNormalizer.latinize(recognizedText.toUpperCase());
    return MrzParser.parse(text) ?? VisualZoneParser.parse(text);
  }

  static ParsedFields parseFields(String recognizedText) {
    final text = OcrNormalizer.latinize(recognizedText.toUpperCase());

    final mrz = MrzParser.parse(text);
    if (mrz != null) {
      return ParsedFields(
        documentNumber: mrz.documentNumber,
        pinfl: mrz.pinfl,
        birthDate: mrz.birthDate,
        fromMrz: true,
      );
    }
    return VisualZoneParser.parseFields(text);
  }
}
