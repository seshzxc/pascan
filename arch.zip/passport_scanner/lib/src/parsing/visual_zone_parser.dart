import '../models/parsed_fields.dart';
import '../models/scan_result.dart';
import 'ocr_normalizer.dart';

abstract final class VisualZoneParser {
  static final _tokenSplitter = RegExp(r'[^A-Z0-9]+');
  static final _documentNumberPattern = RegExp(r'^[A-Z]{2}\d{7}$');
  static final _pinflPattern = RegExp(r'^\d{14}$');
  static final _datePattern = RegExp(
    r'([0-9OQDILZSGB]{2})[.,\t ]+([0-9OQDILZSGB]{2})[.,\t ]*([0-9OQDILZSGB]{4})',
  );
  static final _birthLabelPattern = RegExp(r'BIRTH|TUG');

  static ScanResult? parse(String text) {
    final fields = parseFields(text);
    if (fields.birthDate == null ||
        (fields.documentNumber == null && fields.pinfl == null)) {
      return null;
    }
    return ScanResult(
      documentNumber: fields.documentNumber,
      pinfl: fields.pinfl,
      birthDate: fields.birthDate!,
      source: DocDataSource.visualZone,
    );
  }

  static ParsedFields parseFields(String text) {
    final upper = text.toUpperCase();
    return ParsedFields(
      documentNumber: _findDocumentNumber(upper),
      pinfl: _findPinfl(upper),
      birthDate: _findBirthDate(upper),
    );
  }

  static String? _findDocumentNumber(String text) {
    for (final token in _tokens(text)) {
      if (token.length != 9) continue;
      final candidate = OcrNormalizer.letters(token.substring(0, 2)) +
          OcrNormalizer.digits(token.substring(2));
      if (_documentNumberPattern.hasMatch(candidate)) return candidate;
    }
    return null;
  }

  static String? _findPinfl(String text) {
    for (final token in _tokens(text)) {
      if (token.length != 14) continue;
      final candidate = OcrNormalizer.digits(token);
      if (_pinflPattern.hasMatch(candidate)) return candidate;
    }
    return null;
  }

  static Iterable<String> _tokens(String text) =>
      text.split(_tokenSplitter).where((t) => t.isNotEmpty);

  static DateTime? _findBirthDate(String text) {
    final lines = text.split('\n');
    for (var i = 0; i < lines.length; i++) {
      if (!_birthLabelPattern.hasMatch(lines[i])) continue;
      final sameLine = _firstDateIn(lines[i]);
      if (sameLine != null) return sameLine;
      if (i + 1 < lines.length) {
        final nextLine = _firstDateIn(lines[i + 1]);
        if (nextLine != null) return nextLine;
      }
    }

    final now = DateTime.now();
    final past = _allDatesIn(text).where((d) => !d.isAfter(now)).toList()
      ..sort();
    return past.isEmpty ? null : past.first;
  }

  static DateTime? _firstDateIn(String line) {
    for (final date in _allDatesIn(line)) {
      return date;
    }
    return null;
  }

  static Iterable<DateTime> _allDatesIn(String text) sync* {
    for (final match in _datePattern.allMatches(text)) {
      final day = int.parse(OcrNormalizer.digits(match.group(1)!));
      final month = _normalizeMonth(OcrNormalizer.digits(match.group(2)!));
      final yearRaw = OcrNormalizer.digits(match.group(3)!);
      final year = _normalizeYear(yearRaw);
      if (year == null || month == null || day < 1 || day > 31) {
        continue;
      }
      final date = DateTime(year, month, day);
      if (date.month != month || date.day != day) continue;
      yield date;
    }
  }

  static const _monthLeadFixes = <String, String>{
    '8': '0',
    '6': '0',
    '9': '0',
    '4': '1',
    '7': '1',
  };

  static int? _normalizeMonth(String raw) {
    final direct = int.parse(raw);
    if (direct >= 1 && direct <= 12) return direct;

    final fixedLead = _monthLeadFixes[raw[0]];
    if (fixedLead == null) return null;
    final corrected = int.parse('$fixedLead${raw[1]}');
    return corrected >= 1 && corrected <= 12 ? corrected : null;
  }

  static int? _normalizeYear(String raw) {
    final year = int.parse(raw);
    return year >= 1900 && year <= 2100 ? year : null;
  }
}
