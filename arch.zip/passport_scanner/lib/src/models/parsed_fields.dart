class ParsedFields {
  const ParsedFields({
    this.documentNumber,
    this.pinfl,
    this.birthDate,
    this.fromMrz = false,
  });

  static const empty = ParsedFields();

  final String? documentNumber;
  final String? pinfl;
  final DateTime? birthDate;
  final bool fromMrz;

  bool get isEmpty =>
      documentNumber == null && pinfl == null && birthDate == null;
}
