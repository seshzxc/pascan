import 'dart:async';
import 'dart:ui' show Rect;

import 'package:flutter/foundation.dart';

import '../models/scan_result.dart';
import '../parsing/document_parser.dart';
import 'messages.g.dart';
import 'scanner_dispatcher.dart';

class PassportScannerController {
  PassportScannerController({
    this.fieldConfirmations = 3,
    this.throttle = const Duration(milliseconds: 300),
    this.roi,
    this.debugLogging = false,
  }) : assert(
          roi == null ||
              (roi.left >= 0 &&
                  roi.top >= 0 &&
                  roi.right <= 1 &&
                  roi.bottom <= 1 &&
                  roi.left < roi.right &&
                  roi.top < roi.bottom),
          'roi must be normalized within 0..1 and non-empty',
        );

  static int _nextSessionId = 0;

  final int fieldConfirmations;
  final Duration throttle;
  final Rect? roi;
  final bool debugLogging;

  final int _sessionId = _nextSessionId++;
  final _host = ScannerHostApi();
  final _completer = Completer<ScanResult>();
  final _numberVotes = <String, int>{};
  final _pinflVotes = <String, int>{};
  final _birthVotes = <DateTime, int>{};

  PreviewInfo? _preview;
  bool _disposed = false;

  PreviewInfo? get preview => _preview;

  Future<ScanResult> get result => _completer.future;

  Future<PreviewInfo> start() async {
    ScannerDispatcher.register(_sessionId, _onRecognizedText);
    final roi = this.roi;
    final preview = await _host.start(
      _sessionId,
      throttle.inMilliseconds,
      roi == null
          ? null
          : ScanRoi(
              left: roi.left,
              top: roi.top,
              right: roi.right,
              bottom: roi.bottom,
            ),
    );
    if (_disposed) {
      await _host.stop(_sessionId);
      return preview;
    }
    _preview = preview;
    return preview;
  }

  Future<void> pause() async {
    if (_disposed || _completer.isCompleted) return;
    await _host.pause(_sessionId);
  }

  Future<void> resume() async {
    if (_disposed || _completer.isCompleted) return;
    await _host.resume(_sessionId);
  }

  void _onRecognizedText(String text) {
    if (_disposed || _completer.isCompleted) return;

    final fields = DocumentParser.parseFields(text);
    if (debugLogging) {
      debugPrint('=== PASSPORT_SCANNER OCR ===\n$text');
      debugPrint('=== FIELDS: number=${fields.documentNumber} '
          'pinfl=${fields.pinfl} birth=${fields.birthDate} '
          'mrz=${fields.fromMrz} ===');
    }
    if (fields.isEmpty) return;

    if (fields.fromMrz && fields.birthDate != null) {
      _complete(
        ScanResult(
          documentNumber: fields.documentNumber,
          pinfl: fields.pinfl,
          birthDate: fields.birthDate!,
          source: DocDataSource.mrz,
        ),
      );
      return;
    }

    _vote(_numberVotes, fields.documentNumber);
    _vote(_pinflVotes, fields.pinfl);
    _vote(_birthVotes, fields.birthDate);

    final birthDate = _winner(_birthVotes);
    final number = _winner(_numberVotes);
    final pinfl = _winner(_pinflVotes);
    if (debugLogging) {
      debugPrint('=== VOTES: number=$_numberVotes birth=$_birthVotes ===');
    }
    if (birthDate == null || (number == null && pinfl == null)) return;

    _complete(
      ScanResult(
        documentNumber: number,
        pinfl: pinfl,
        birthDate: birthDate,
        source: DocDataSource.visualZone,
      ),
    );
  }

  void _vote<T>(Map<T, int> votes, T? value) {
    if (value == null) return;
    votes[value] = (votes[value] ?? 0) + 1;
  }

  T? _winner<T>(Map<T, int> votes) {
    for (final entry in votes.entries) {
      if (entry.value >= fieldConfirmations) return entry.key;
    }
    return null;
  }

  void _complete(ScanResult result) {
    if (_completer.isCompleted) return;
    _completer.complete(result);
    unawaited(_host.stop(_sessionId));
  }

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    ScannerDispatcher.unregister(_sessionId);
    _preview = null;
    await _host.stop(_sessionId);
  }
}
