import 'package:pigeon/pigeon.dart';

@ConfigurePigeon(
  PigeonOptions(
    dartOut: 'lib/src/scanner/messages.g.dart',
    kotlinOut: 'android/src/main/kotlin/uz/passport_scanner/Messages.g.kt',
    kotlinOptions: KotlinOptions(
      package: 'uz.passport_scanner',
      errorClassName: 'PassportScannerFlutterError',
    ),
    swiftOut: 'ios/passport_scanner/Sources/passport_scanner/Messages.g.swift',
    swiftOptions: SwiftOptions(
      errorClassName: 'PassportScannerPigeonError',
    ),
    dartPackageName: 'passport_scanner',
  ),
)
class ScanRoi {
  ScanRoi({
    required this.left,
    required this.top,
    required this.right,
    required this.bottom,
  });

  final double left;
  final double top;
  final double right;
  final double bottom;
}

class PreviewInfo {
  PreviewInfo({
    required this.textureId,
    required this.width,
    required this.height,
    required this.rotationDegrees,
  });

  final int textureId;
  final double width;
  final double height;
  final int rotationDegrees;
}

@HostApi()
abstract class ScannerHostApi {
  @async
  PreviewInfo start(int sessionId, int throttleMs, ScanRoi? roi);

  @async
  void pause(int sessionId);

  @async
  void resume(int sessionId);

  @async
  void stop(int sessionId);
}

@FlutterApi()
abstract class ScannerFlutterApi {
  void onRecognizedText(int sessionId, String text);
}
