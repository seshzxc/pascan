import 'package:card_scanner/card_scanner.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Card number', () {
    test('parses clean grouped visa', () {
      final result = CardParser.parse('4012 8888 8888 1881');
      expect(result, isNotNull);
      expect(result!.number, '4012888888881881');
      expect(result.network, CardNetwork.visa);
    });

    test('recovers uzcard from O/0 confusion via Luhn', () {
      final result = CardParser.parse('86OO 526O 1815 9O88');
      expect(result?.number, '8600526018159088');
      expect(result?.network, CardNetwork.uzcard);
    });

    test('recovers humo from O/0 confusion via Luhn', () {
      final result = CardParser.parse('986O 3O16 6131 86O2');
      expect(result?.number, '9860301661318602');
      expect(result?.network, CardNetwork.humo);
    });

    test('parses amex 4-6-5 grouping', () {
      final result = CardParser.parse('3782 822463 10005');
      expect(result?.number, '378282246310005');
      expect(result?.network, CardNetwork.amex);
    });

    test('parses 2-series mastercard', () {
      final result = CardParser.parse('2221 0000 0000 0009');
      expect(result?.network, CardNetwork.mastercard);
    });

    test('extracts number surrounded by noise', () {
      final result = CardParser.parse('ID 1234 4012888888881881 REF');
      expect(result?.number, '4012888888881881');
    });

    test('rejects number failing Luhn', () {
      expect(CardParser.parse('4012 8888 8888 1882'), isNull);
    });

    test('does not span lines', () {
      expect(CardParser.parse('4012 8888\n8888 1881'), isNull);
    });
  });

  group('Expiry', () {
    test('reads labeled expiry', () {
      final result = CardParser.parse('4012888888881881\nVALID THRU 05/28');
      expect(result?.expiry, const CardExpiry(month: 5, year: 2028));
    });

    test('reads expiry on next line after label', () {
      final result = CardParser.parse('4012888888881881\nVALID THRU\n05/28');
      expect(result?.expiry, const CardExpiry(month: 5, year: 2028));
    });

    test('prefers valid thru over member since', () {
      final result = CardParser.parse(
        '4012888888881881\nMEMBER SINCE 05/18\nVALID THRU 09/27',
      );
      expect(result?.expiry, const CardExpiry(month: 9, year: 2027));
    });

    test('picks latest date when label is missing', () {
      final result = CardParser.parse('4012888888881881\n05/18\n09/27');
      expect(result?.expiry, const CardExpiry(month: 9, year: 2027));
    });

    test('recovers O/0 confusion in expiry', () {
      final result = CardParser.parse('4012888888881881\nVALID THRU O9/27');
      expect(result?.expiry, const CardExpiry(month: 9, year: 2027));
    });

    test('does not treat card number as expiry', () {
      final result = CardParser.parse('4012 8888 8888 1881');
      expect(result?.expiry, isNull);
    });
  });

  group('Holder', () {
    test('reads two-word holder', () {
      final result = CardParser.parse(
        '4012888888881881\nVALID THRU 05/28\nIVAN PETROV',
      );
      expect(result?.holder, 'IVAN PETROV');
    });

    test('ignores bank and product keywords', () {
      final result = CardParser.parse(
        '4012888888881881\nKAPITAL BANK\nVISA GOLD\nDEBIT CARD',
      );
      expect(result?.holder, isNull);
    });

    test('reads holder with hyphen', () {
      final result = CardParser.parse('4012888888881881\nANNA SMITH-JONES');
      expect(result?.holder, 'ANNA SMITH-JONES');
    });
  });

  group('Result', () {
    test('masks number in toString', () {
      final result = CardParser.parse('4012888888881881');
      expect(result.toString(), contains('401288******1881'));
      expect(result.toString(), isNot(contains('4012888888881881')));
    });

    test('merges missing fields across frames', () {
      const a = CardScanResult(
        number: '4012888888881881',
        network: CardNetwork.visa,
        expiry: CardExpiry(month: 5, year: 2028),
      );
      const b = CardScanResult(
        number: '4012888888881881',
        network: CardNetwork.visa,
        holder: 'IVAN PETROV',
      );
      final merged = a.mergedWith(b);
      expect(merged.expiry, const CardExpiry(month: 5, year: 2028));
      expect(merged.holder, 'IVAN PETROV');
    });
  });
}
