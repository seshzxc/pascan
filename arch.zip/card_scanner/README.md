# card_scanner

Live-сканер банковских карт. Извлекает номер (Luhn-валидация), платёжную систему, срок и имя держателя из потока камеры.

## Как работает

Камера и OCR полностью в нативе (CameraX + ML Kit на Android, AVCaptureSession + Vision на iOS). В Dart уходят только id текстуры для превью и распознанный текст — кадры через channel не копируются.

Парсинг в Dart: номер по Luhn (принимается только валидный), сеть по BIN, срок `MM/YY`, имя держателя. Результат подтверждается на `confirmationFrames` кадрах с одинаковым номером; недостающие поля домердживаются с последующих кадров.

## Превью

Заполняет весь виджет (`BoxFit.cover`). Разрешение: приоритет 16:9, короткая сторона ≥720. Ориентация обрабатывается нативом.

## Использование

```dart
const roi = Rect.fromLTRB(0.05, 0.3, 0.95, 0.7);

CardScannerView(
  controller: CardScannerController(roi: roi),
  overlay: const ScanFrameOverlay(roi: roi),
  onScanned: (result) {
    result.number;
    result.maskedNumber;
    result.network;
    result.expiry;
    result.holder;
  },
)
```

Со своим UI:

```dart
final controller = CardScannerController(requireExpiry: false);
await controller.start();
final result = await controller.result;
await controller.dispose();
```

Lifecycle приложения view обрабатывает сам (pause/resume). При внешнем контроллере вызывай `controller.dispose()` сам.

Параметры контроллера: `confirmationFrames` (default 2), `requireExpiry` (default true), `requireHolder` (default false), `throttle` (default 300ms), `roi`.

## ROI

Нормализованные координаты (0..1) в системе **кадра**, фильтрует строки OCR до парсинга. Рамку рисует `overlay` — передавай тот же `Rect` в оба, они совпадают при любом кропе. Не сужай ROI сильнее эмбоссированного номера.

## Настройка платформ

**Android** — `minSdkVersion 21`, в манифест приложения:

```xml
<uses-permission android:name="android.permission.CAMERA" />
```

**iOS** — `platform :ios, '13.0'`, в `Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>Сканирование карты</string>
```

Runtime-запрос разрешения — ответственность приложения до показа `CardScannerView`.

## Кодогенерация

После изменения `pigeons/messages.dart`:

```bash
dart run pigeon --input pigeons/messages.dart
```

Сгенерированные файлы (`messages.g.dart`, `Messages.g.kt`, `Messages.g.swift`) не включены в архив — сгенерируй перед первой сборкой.

## Безопасность

Номер карты — чувствительные данные: в `toString` он маскируется, сырой OCR-текст логируется только под явным `unsafeDebugLogRawText`. Не включай его в проде.

## Тесты

```bash
flutter test
```
