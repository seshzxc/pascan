import 'dart:async';
import 'dart:ui' show Rect;

import 'package:flutter/foundation.dart';

import '../models/card_scan_result.dart';
import '../parsing/card_parser.dart';
import 'messages.g.dart';
import 'scanner_dispatcher.dart';

class CardScannerController {
  CardScannerController({
    this.confirmationFrames = 2,
    this.requireExpiry = true,
    this.requireHolder = false,
    this.throttle = const Duration(milliseconds: 300),
    this.roi,
    this.debugLogging = false,
    this.unsafeDebugLogRawText = false,
  }) : assert(
          roi == null ||
              (roi.left >= 0 &&
                  roi.top >= 0 &&
                  roi.right <= 1 &&
                  roi.bottom <= 1 &&
                  roi.left < roi.right &&
                  roi.top < roi.bottom),
          'roi must be normalized within 0..1 and non-empty',
        );

  static int _nextSessionId = 0;

  final int confirmationFrames;
  final bool requireExpiry;
  final bool requireHolder;
  final Duration throttle;
  final Rect? roi;
  final bool debugLogging;
  final bool unsafeDebugLogRawText;

  final int _sessionId = _nextSessionId++;
  final _host = ScannerHostApi();
  final _completer = Completer<CardScanResult>();

  PreviewInfo? _preview;
  CardScanResult? _pending;
  int _pendingCount = 0;
  bool _disposed = false;

  PreviewInfo? get preview => _preview;

  Future<CardScanResult> get result => _completer.future;

  Future<PreviewInfo> start() async {
    ScannerDispatcher.register(_sessionId, _onRecognizedText);
    final roi = this.roi;
    final preview = await _host.start(
      _sessionId,
      throttle.inMilliseconds,
      roi == null
          ? null
          : ScanRoi(
              left: roi.left,
              top: roi.top,
              right: roi.right,
              bottom: roi.bottom,
            ),
    );
    if (_disposed) {
      await _host.stop(_sessionId);
      return preview;
    }
    _preview = preview;
    return preview;
  }

  Future<void> pause() async {
    if (_disposed || _completer.isCompleted) return;
    await _host.pause(_sessionId);
  }

  Future<void> resume() async {
    if (_disposed || _completer.isCompleted) return;
    await _host.resume(_sessionId);
  }

  void _onRecognizedText(String text) {
    if (_disposed || _completer.isCompleted) return;

    if (unsafeDebugLogRawText) {
      debugPrint('=== CARD_SCANNER RAW OCR (UNSAFE) ===\n$text');
    }

    final parsed = CardParser.parse(text);
    if (debugLogging) debugPrint('=== CARD_SCANNER PARSED: $parsed ===');
    if (parsed == null) return;

    final pending = _pending;
    if (pending != null && pending.number == parsed.number) {
      _pending = pending.mergedWith(parsed);
      _pendingCount++;
    } else {
      _pending = parsed;
      _pendingCount = 1;
    }

    final merged = _pending!;
    if (_pendingCount < confirmationFrames) return;
    if (requireExpiry && merged.expiry == null) return;
    if (requireHolder && merged.holder == null) return;
    _complete(merged);
  }

  void _complete(CardScanResult result) {
    if (_completer.isCompleted) return;
    _completer.complete(result);
    unawaited(_host.stop(_sessionId));
  }

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    ScannerDispatcher.unregister(_sessionId);
    _preview = null;
    await _host.stop(_sessionId);
  }
}
