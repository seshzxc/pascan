import '../models/card_network.dart';
import 'luhn.dart';
import 'ocr_normalizer.dart';

abstract final class CardNumberParser {
  static const _lengths = [19, 16, 15, 14, 13];
  static final _candidatePattern =
      RegExp(r'[0-9OQDILZSGB][0-9OQDILZSGB \t\-]{11,25}[0-9OQDILZSGB]');
  static final _separators = RegExp(r'[ \t\-]');
  static final _digitsOnly = RegExp(r'^\d+$');

  static String? parse(String text) {
    for (final line in text.toUpperCase().split('\n')) {
      for (final match in _candidatePattern.allMatches(line)) {
        final normalized = OcrNormalizer.digits(
          match.group(0)!.replaceAll(_separators, ''),
        );
        if (!_digitsOnly.hasMatch(normalized)) continue;
        final found = _findValid(normalized);
        if (found != null) return found;
      }
    }
    return null;
  }

  static String? _findValid(String digits) {
    for (final length in _lengths) {
      if (digits.length < length) continue;
      for (var start = 0; start + length <= digits.length; start++) {
        final candidate = digits.substring(start, start + length);
        if (!Luhn.isValid(candidate)) continue;
        if (CardNetwork.fromNumber(candidate) == CardNetwork.unknown) continue;
        return candidate;
      }
    }
    return null;
  }
}
