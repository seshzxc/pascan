abstract final class HolderParser {
  static const _stopWords = <String>{
    'VALID', 'THRU', 'GOOD', 'FROM', 'UNTIL', 'EXPIRES', 'EXPIRY', 'EXP',
    'MEMBER', 'SINCE', 'DEBIT', 'CREDIT', 'PREPAID', 'CARD', 'CARDHOLDER',
    'BANK', 'BANKI', 'VISA', 'MASTERCARD', 'MAESTRO', 'ELECTRON', 'HUMO',
    'UZCARD', 'MIR', 'UNIONPAY', 'AMEX', 'EXPRESS', 'AMERICAN', 'JCB',
    'CLASSIC', 'GOLD', 'PLATINUM', 'INFINITE', 'SIGNATURE', 'BUSINESS',
    'CORPORATE', 'WORLD', 'STANDARD', 'PREMIUM', 'ELITE', 'INTERNATIONAL',
    'AUTHORIZED', 'CUSTOMER', 'SERVICE', 'CENTER', 'CONTACTLESS', 'CHIP',
    'BONUS', 'VIRTUAL', 'SALARY', 'PENSION', 'YOUTH', 'ONLINE',
  };

  static final _namePattern = RegExp(r"^[A-Z][A-Z'\-]{1,}$");

  static String? parse(String text) {
    for (final line in text.toUpperCase().split('\n')) {
      final tokens = line
          .replaceAll(RegExp(r'[^A-Z\x27\- ]'), ' ')
          .split(RegExp(r' +'))
          .where((t) => t.isNotEmpty)
          .toList();
      if (tokens.length < 2 || tokens.length > 4) continue;
      if (tokens.any(_stopWords.contains)) continue;
      if (!tokens.every(_namePattern.hasMatch)) continue;
      return tokens.join(' ');
    }
    return null;
  }
}
