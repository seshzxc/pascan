import '../models/card_network.dart';
import '../models/card_scan_result.dart';
import 'card_number_parser.dart';
import 'expiry_parser.dart';
import 'holder_parser.dart';

abstract final class CardParser {
  static CardScanResult? parse(String recognizedText) {
    final number = CardNumberParser.parse(recognizedText);
    if (number == null) return null;
    return CardScanResult(
      number: number,
      network: CardNetwork.fromNumber(number),
      expiry: ExpiryParser.parse(recognizedText),
      holder: HolderParser.parse(recognizedText),
    );
  }
}
