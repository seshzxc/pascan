enum CardNetwork {
  uzcard,
  humo,
  visa,
  mastercard,
  maestro,
  amex,
  mir,
  unionPay,
  jcb,
  unknown;

  static CardNetwork fromNumber(String number) {
    if (_hasPrefix(number, 4, 8600, 8600)) return CardNetwork.uzcard;
    if (_hasPrefix(number, 4, 9860, 9860)) return CardNetwork.humo;
    if (_hasPrefix(number, 4, 2200, 2204)) return CardNetwork.mir;
    if (_hasPrefix(number, 4, 3528, 3589)) return CardNetwork.jcb;
    if (_hasPrefix(number, 2, 34, 34) || _hasPrefix(number, 2, 37, 37)) {
      return CardNetwork.amex;
    }
    if (_hasPrefix(number, 2, 51, 55)) return CardNetwork.mastercard;
    if (_hasPrefix(number, 4, 2221, 2720)) return CardNetwork.mastercard;
    if (_hasPrefix(number, 2, 50, 50) || _hasPrefix(number, 2, 56, 58)) {
      return CardNetwork.maestro;
    }
    if (_hasPrefix(number, 2, 62, 62)) return CardNetwork.unionPay;
    if (_hasPrefix(number, 1, 4, 4)) return CardNetwork.visa;
    return CardNetwork.unknown;
  }

  static bool _hasPrefix(String number, int length, int min, int max) {
    if (number.length < length) return false;
    final prefix = int.tryParse(number.substring(0, length));
    return prefix != null && prefix >= min && prefix <= max;
  }
}
