import 'card_expiry.dart';
import 'card_network.dart';

class CardScanResult {
  const CardScanResult({
    required this.number,
    required this.network,
    this.expiry,
    this.holder,
  });

  final String number;
  final CardNetwork network;
  final CardExpiry? expiry;
  final String? holder;

  String get maskedNumber => number.length < 10
      ? '*' * number.length
      : '${number.substring(0, 6)}${'*' * (number.length - 10)}'
          '${number.substring(number.length - 4)}';

  CardScanResult mergedWith(CardScanResult other) => CardScanResult(
        number: number,
        network: network,
        expiry: expiry ?? other.expiry,
        holder: holder ?? other.holder,
      );

  @override
  bool operator ==(Object other) =>
      other is CardScanResult &&
      other.number == number &&
      other.network == network &&
      other.expiry == expiry &&
      other.holder == holder;

  @override
  int get hashCode => Object.hash(number, network, expiry, holder);

  @override
  String toString() => 'CardScanResult(number: $maskedNumber, '
      'network: $network, expiry: $expiry, holder: $holder)';
}
