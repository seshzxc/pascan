import 'package:card_scanner/card_scanner.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Card number', () {
    test('parses clean grouped 16-digit number', () {
      final result = CardParser.parse('4012 8888 8888 1881');
      expect(result?.number, '4012888888881881');
    });

    test('recovers digits from O/0 confusion', () {
      final result = CardParser.parse('86OO 526O 1815 9O88');
      expect(result?.number, '8600526018159088');
    });

    test('extracts number surrounded by noise', () {
      final result = CardParser.parse('REF 4012888888881881 ID');
      expect(result?.number, '4012888888881881');
    });

    test('rejects shorter than 16 digits', () {
      expect(CardParser.parse('3782 822463 10005'), isNull);
    });

    test('accepts number failing Luhn by default', () {
      final result = CardParser.parse('4012 8888 8888 1882');
      expect(result?.number, '4012888888881882');
    });

    test('rejects number failing Luhn when validation enabled', () {
      expect(
        CardParser.parse('4012 8888 8888 1882', validateLuhn: true),
        isNull,
      );
    });

    test('finds valid Luhn window inside longer digit run', () {
      final result =
          CardParser.parse('9 4012 8888 8888 1881', validateLuhn: true);
      expect(result?.number, '4012888888881881');
    });
  });

  group('Expiry', () {
    test('parses labeled expiry', () {
      final result = CardParser.parse('4012888888881881\nVALID THRU 05/28');
      expect(result?.expiry, const CardExpiry(month: 5, year: 2028));
    });

    test('parses expiry on next line after label', () {
      final result = CardParser.parse('4012888888881881\nEXPIRES\n11/27');
      expect(result?.expiry, const CardExpiry(month: 11, year: 2027));
    });

    test('picks latest date when unlabeled', () {
      final result = CardParser.parse('4012888888881881\n01/24 09/29');
      expect(result?.expiry, const CardExpiry(month: 9, year: 2029));
    });

    test('ignores member since dates', () {
      final result =
          CardParser.parse('4012888888881881\nMEMBER SINCE 03/20\n06/28');
      expect(result?.expiry, const CardExpiry(month: 6, year: 2028));
    });

    test('rejects invalid month', () {
      final result = CardParser.parse('4012888888881881\n13/28');
      expect(result?.expiry, isNull);
    });
  });

  group('Holder', () {
    test('parses two-word name', () {
      final result = CardParser.parse('4012888888881881\nIVAN PETROV');
      expect(result?.holder, 'IVAN PETROV');
    });

    test('skips lines with stop words', () {
      final result =
          CardParser.parse('4012888888881881\nVALID THRU\nIVAN PETROV');
      expect(result?.holder, 'IVAN PETROV');
    });

    test('rejects placeholder with OCR-dropped letter', () {
      final result = CardParser.parse('4012888888881881\nCARDH LDER NAME');
      expect(result?.holder, isNull);
    });

    test('rejects intact cardholder placeholder', () {
      final result = CardParser.parse('4012888888881881\nCARDHOLDER NAME');
      expect(result?.holder, isNull);
    });

    test('parses hyphenated name', () {
      final result = CardParser.parse('4012888888881881\nANNA SMITH-JONES');
      expect(result?.holder, 'ANNA SMITH-JONES');
    });
  });

  group('Result', () {
    test('exposes full number in toString', () {
      final result = CardParser.parse('4012888888881881');
      expect(result.toString(), contains('4012888888881881'));
    });

    test('merges missing fields across frames', () {
      const a = CardScanResult(
        number: '4012888888881881',
        expiry: CardExpiry(month: 5, year: 2028),
      );
      const b = CardScanResult(
        number: '4012888888881881',
        holder: 'IVAN PETROV',
      );
      final merged = a.mergedWith(b);
      expect(merged.expiry, const CardExpiry(month: 5, year: 2028));
      expect(merged.holder, 'IVAN PETROV');
    });
  });
}
