import 'package:pigeon/pigeon.dart';

@ConfigurePigeon(
  PigeonOptions(
    dartOut: 'lib/src/scanner/messages.g.dart',
    kotlinOut: 'android/src/main/kotlin/uz/card_scanner/Messages.g.kt',
    kotlinOptions: KotlinOptions(
      package: 'uz.card_scanner',
      errorClassName: 'CardScannerFlutterError',
    ),
    swiftOut: 'ios/card_scanner/Sources/card_scanner/Messages.g.swift',
    swiftOptions: SwiftOptions(
      errorClassName: 'CardScannerPigeonError',
    ),
    dartPackageName: 'card_scanner',
  ),
)
class ScanRoi {
  ScanRoi({
    required this.left,
    required this.top,
    required this.right,
    required this.bottom,
  });

  final double left;
  final double top;
  final double right;
  final double bottom;
}

class PreviewInfo {
  PreviewInfo({
    required this.textureId,
    required this.width,
    required this.height,
    required this.rotationDegrees,
  });

  final int textureId;
  final double width;
  final double height;
  final int rotationDegrees;
}

@HostApi()
abstract class ScannerHostApi {
  @async
  PreviewInfo start(int sessionId, int throttleMs, ScanRoi? roi);

  @async
  void pause(int sessionId);

  @async
  void resume(int sessionId);

  @async
  void stop(int sessionId);
}

@FlutterApi()
abstract class ScannerFlutterApi {
  void onRecognizedText(int sessionId, String text);
}
