// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "card_scanner",
    platforms: [
        .iOS("13.0"),
    ],
    products: [
        .library(name: "card-scanner", targets: ["card_scanner"]),
    ],
    dependencies: [
        .package(name: "FlutterFramework", path: "../FlutterFramework"),
    ],
    targets: [
        .target(
            name: "card_scanner",
            dependencies: [
                .product(name: "FlutterFramework", package: "FlutterFramework"),
            ]
        ),
    ]
)
