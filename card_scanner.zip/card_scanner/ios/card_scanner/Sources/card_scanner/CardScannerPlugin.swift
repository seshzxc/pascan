import AVFoundation
import Flutter
import Vision

public class CardScannerPlugin: NSObject, FlutterPlugin, FlutterTexture, ScannerHostApi,
    AVCaptureVideoDataOutputSampleBufferDelegate
{
    private var registrar: FlutterPluginRegistrar?
    private var flutterApi: ScannerFlutterApi?

    private let sessionQueue = DispatchQueue(label: "uz.card_scanner.session")
    private let bufferLock = NSLock()

    private var session: AVCaptureSession?
    private var textureId: Int64?
    private var latestBuffer: CVPixelBuffer?
    private var throttle: TimeInterval = 0.3
    private var lastProcessedAt: TimeInterval = 0
    private var processing = false
    private var roi: ScanRoi?
    private var sessionId: Int64?

    public static func register(with registrar: FlutterPluginRegistrar) {
        let instance = CardScannerPlugin()
        instance.registrar = registrar
        instance.flutterApi = ScannerFlutterApi(binaryMessenger: registrar.messenger())
        ScannerHostApiSetup.setUp(binaryMessenger: registrar.messenger(), api: instance)
    }

    public func copyPixelBuffer() -> Unmanaged<CVPixelBuffer>? {
        bufferLock.lock()
        defer { bufferLock.unlock() }
        guard let buffer = latestBuffer else { return nil }
        return Unmanaged.passRetained(buffer)
    }

    func start(
        sessionId: Int64,
        throttleMs: Int64,
        roi: ScanRoi?,
        completion: @escaping (Result<PreviewInfo, Error>) -> Void
    ) {
        self.sessionId = sessionId
        throttle = Double(throttleMs) / 1000.0
        self.roi = roi

        guard AVCaptureDevice.authorizationStatus(for: .video) == .authorized else {
            completion(.failure(CardScannerPigeonError(
                code: "no_permission",
                message: "Camera permission is not granted",
                details: nil
            )))
            return
        }
        guard let registrar else {
            completion(.failure(CardScannerPigeonError(
                code: "no_registrar", message: "Plugin is not registered", details: nil
            )))
            return
        }

        sessionQueue.async { [weak self] in
            guard let self else { return }
            do {
                let info = try self.configureSession(registrar: registrar)
                DispatchQueue.main.async { completion(.success(info)) }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private func configureSession(registrar: FlutterPluginRegistrar) throws -> PreviewInfo {
        teardown()

        guard let device = AVCaptureDevice.default(
            .builtInWideAngleCamera, for: .video, position: .back
        ) else {
            throw CardScannerPigeonError(
                code: "no_camera", message: "No back camera available", details: nil
            )
        }

        let session = AVCaptureSession()
        session.beginConfiguration()
        session.sessionPreset =
            session.canSetSessionPreset(.hd1920x1080) ? .hd1920x1080 : .hd1280x720

        let input = try AVCaptureDeviceInput(device: device)
        guard session.canAddInput(input) else {
            throw CardScannerPigeonError(
                code: "no_input", message: "Cannot add camera input", details: nil
            )
        }
        session.addInput(input)

        let output = AVCaptureVideoDataOutput()
        output.videoSettings = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: sessionQueue)
        guard session.canAddOutput(output) else {
            throw CardScannerPigeonError(
                code: "no_output", message: "Cannot add video output", details: nil
            )
        }
        session.addOutput(output)

        if let connection = output.connection(with: .video),
            connection.isVideoOrientationSupported
        {
            connection.videoOrientation = .portrait
        }
        session.commitConfiguration()
        session.startRunning()
        self.session = session

        let id = registrar.textures().register(self)
        textureId = id

        let dimensions = CMVideoFormatDescriptionGetDimensions(device.activeFormat.formatDescription)
        return PreviewInfo(
            textureId: id,
            width: Double(dimensions.height),
            height: Double(dimensions.width),
            rotationDegrees: 0
        )
    }

    public func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard let buffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        bufferLock.lock()
        latestBuffer = buffer
        bufferLock.unlock()

        if let textureId {
            registrar?.textures().textureFrameAvailable(textureId)
        }

        let now = Date().timeIntervalSince1970
        guard !processing, now - lastProcessedAt >= throttle else { return }
        processing = true
        lastProcessedAt = now
        recognize(buffer: buffer)
    }

    private func recognize(buffer: CVPixelBuffer) {
        let request = VNRecognizeTextRequest { [weak self] request, _ in
            guard let self else { return }
            defer { self.processing = false }

            let observations = request.results as? [VNRecognizedTextObservation] ?? []
            let text = observations
                .filter { self.isInsideRoi($0.boundingBox) }
                .compactMap { $0.topCandidates(1).first?.string }
                .joined(separator: "\n")
            guard !text.isEmpty, let activeSession = self.sessionId else { return }
            DispatchQueue.main.async {
                self.flutterApi?.onRecognizedText(
                    sessionId: activeSession, text: text
                ) { _ in }
            }
        }
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        request.recognitionLanguages = ["en-US"]

        let handler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: .up, options: [:])
        do {
            try handler.perform([request])
        } catch {
            processing = false
        }
    }

    private func isInsideRoi(_ boundingBox: CGRect) -> Bool {
        guard let roi else { return true }

        let centerX = boundingBox.midX
        let centerY = 1.0 - boundingBox.midY

        return centerX >= roi.left && centerX <= roi.right
            && centerY >= roi.top && centerY <= roi.bottom
    }

    func pause(sessionId: Int64, completion: @escaping (Result<Void, Error>) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self, self.sessionId == sessionId else {
                DispatchQueue.main.async { completion(.success(())) }
                return
            }
            self.session?.stopRunning()
            DispatchQueue.main.async { completion(.success(())) }
        }
    }

    func resume(sessionId: Int64, completion: @escaping (Result<Void, Error>) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self, self.sessionId == sessionId else {
                DispatchQueue.main.async { completion(.success(())) }
                return
            }
            if let session = self.session, !session.isRunning {
                session.startRunning()
            }
            DispatchQueue.main.async { completion(.success(())) }
        }
    }

    func stop(sessionId: Int64, completion: @escaping (Result<Void, Error>) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self, self.sessionId == sessionId else {
                DispatchQueue.main.async { completion(.success(())) }
                return
            }
            self.sessionId = nil
            self.roi = nil
            self.teardown()
            DispatchQueue.main.async { completion(.success(())) }
        }
    }

    private func teardown() {
        session?.stopRunning()
        session = nil
        if let textureId {
            registrar?.textures().unregisterTexture(textureId)
        }
        textureId = nil
        bufferLock.lock()
        latestBuffer = nil
        bufferLock.unlock()
        processing = false
    }
}
