Pod::Spec.new do |s|
  s.name             = 'card_scanner'
  s.version          = '0.2.0'
  s.summary          = 'Bank card scanner backed by Apple Vision.'
  s.description      = 'Live camera OCR for bank cards using VNRecognizeTextRequest.'
  s.homepage         = 'https://example.com'
  s.license          = { :type => 'MIT' }
  s.author           = { 'card_scanner' => 'dev@example.com' }
  s.source           = { :path => '.' }
  s.source_files     = 'card_scanner/Sources/card_scanner/**/*.swift'
  s.dependency 'Flutter'
  s.platform         = :ios, '13.0'
  s.frameworks       = 'Vision', 'CoreVideo', 'AVFoundation', 'CoreMedia'
  s.swift_version    = '5.0'
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES' }
end
