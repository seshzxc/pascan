import 'card_expiry.dart';

class CardScanResult {
  const CardScanResult({
    required this.number,
    this.expiry,
    this.holder,
  });

  final String number;
  final CardExpiry? expiry;
  final String? holder;

  CardScanResult mergedWith(CardScanResult other) => CardScanResult(
        number: number,
        expiry: expiry ?? other.expiry,
        holder: holder ?? other.holder,
      );

  @override
  bool operator ==(Object other) =>
      other is CardScanResult &&
      other.number == number &&
      other.expiry == expiry &&
      other.holder == holder;

  @override
  int get hashCode => Object.hash(number, expiry, holder);

  @override
  String toString() =>
      'CardScanResult(number: $number, expiry: $expiry, holder: $holder)';
}
