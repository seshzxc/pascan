class CardExpiry {
  const CardExpiry({required this.month, required this.year});

  final int month;
  final int year;

  DateTime get lastMoment =>
      DateTime(year, month + 1).subtract(const Duration(milliseconds: 1));

  bool get isExpired => DateTime.now().isAfter(lastMoment);

  @override
  bool operator ==(Object other) =>
      other is CardExpiry && other.month == month && other.year == year;

  @override
  int get hashCode => Object.hash(month, year);

  @override
  String toString() =>
      '${month.toString().padLeft(2, '0')}/${year.toString().substring(2)}';
}
