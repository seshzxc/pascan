import '../models/card_scan_result.dart';
import 'card_number_parser.dart';
import 'expiry_parser.dart';
import 'holder_parser.dart';

abstract final class CardParser {
  static CardScanResult? parse(String recognizedText, {bool validateLuhn = false}) {
    final number = CardNumberParser.parse(recognizedText, validateLuhn: validateLuhn);
    if (number == null) return null;
    return CardScanResult(
      number: number,
      expiry: ExpiryParser.parse(recognizedText),
      holder: HolderParser.parse(recognizedText),
    );
  }
}
