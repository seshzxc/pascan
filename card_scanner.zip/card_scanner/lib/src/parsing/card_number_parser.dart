import 'luhn.dart';
import 'ocr_normalizer.dart';

abstract final class CardNumberParser {
  static const length = 16;
  static final _candidatePattern =
      RegExp(r'[0-9OQDILZSGB][0-9OQDILZSGB \t\-]{14,25}[0-9OQDILZSGB]');
  static final _separators = RegExp(r'[ \t\-]');
  static final _digitsOnly = RegExp(r'^\d+$');

  static String? parse(String text, {bool validateLuhn = false}) {
    for (final line in text.toUpperCase().split('\n')) {
      for (final match in _candidatePattern.allMatches(line)) {
        final normalized = OcrNormalizer.digits(
          match.group(0)!.replaceAll(_separators, ''),
        );
        if (!_digitsOnly.hasMatch(normalized)) continue;
        final found = _find(normalized, validateLuhn: validateLuhn);
        if (found != null) return found;
      }
    }
    return null;
  }

  static String? _find(String digits, {required bool validateLuhn}) {
    if (digits.length < length) return null;
    if (digits.length == length) {
      if (validateLuhn && !Luhn.isValid(digits)) return null;
      return digits;
    }
    String? fallback;
    for (var start = 0; start + length <= digits.length; start++) {
      final candidate = digits.substring(start, start + length);
      if (Luhn.isValid(candidate)) return candidate;
      fallback ??= candidate;
    }
    return validateLuhn ? null : fallback;
  }
}
