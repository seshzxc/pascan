abstract final class HolderParser {
  static const _stopWords = <String>{
    'VALID', 'THRU', 'GOOD', 'FROM', 'UNTIL', 'EXPIRES', 'EXPIRY', 'EXP',
    'MEMBER', 'SINCE', 'DEBIT', 'CREDIT', 'PREPAID', 'CARD', 'CARDHOLDER',
    'HOLDER', 'NAME', 'SURNAME',
    'BANK', 'BANKI', 'VISA', 'MASTERCARD', 'MAESTRO', 'ELECTRON', 'HUMO',
    'UZCARD', 'MIR', 'UNIONPAY', 'AMEX', 'EXPRESS', 'AMERICAN', 'JCB',
    'CLASSIC', 'GOLD', 'PLATINUM', 'INFINITE', 'SIGNATURE', 'BUSINESS',
    'CORPORATE', 'WORLD', 'STANDARD', 'PREMIUM', 'ELITE', 'INTERNATIONAL',
    'AUTHORIZED', 'CUSTOMER', 'SERVICE', 'CENTER', 'CONTACTLESS', 'CHIP',
    'BONUS', 'VIRTUAL', 'SALARY', 'PENSION', 'YOUTH', 'ONLINE',
  };

  static final _fuzzyStopWords =
      _stopWords.where((w) => w.length >= 5).toList(growable: false);

  static final _namePattern = RegExp(r"^[A-Z][A-Z'\-]{1,}$");

  static String? parse(String text) {
    for (final line in text.toUpperCase().split('\n')) {
      final tokens = line
          .replaceAll(RegExp(r'[^A-Z\x27\- ]'), ' ')
          .split(RegExp(r' +'))
          .where((t) => t.isNotEmpty)
          .toList();
      if (tokens.length < 2 || tokens.length > 4) continue;
      if (_isStopLine(tokens)) continue;
      if (!tokens.every(_namePattern.hasMatch)) continue;
      return tokens.join(' ');
    }
    return null;
  }

  static bool _isStopLine(List<String> tokens) {
    if (tokens.any(_isStopWord)) return true;
    final collapsed = tokens.join();
    return _fuzzyStopWords
        .any((word) => word.length >= 8 && _withinOneEdit(collapsed, word));
  }

  static bool _isStopWord(String token) {
    if (_stopWords.contains(token)) return true;
    if (token.length < 4) return false;
    return _fuzzyStopWords.any((word) => _withinOneEdit(token, word));
  }

  static bool _withinOneEdit(String a, String b) {
    if ((a.length - b.length).abs() > 1) return false;
    if (a == b) return true;
    final (shorter, longer) = a.length <= b.length ? (a, b) : (b, a);
    var i = 0;
    var j = 0;
    var edits = 0;
    while (i < shorter.length && j < longer.length) {
      if (shorter[i] == longer[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (shorter.length == longer.length) {
        i++;
        j++;
      } else {
        j++;
      }
    }
    edits += longer.length - j;
    return edits <= 1;
  }
}
