import '../models/card_expiry.dart';
import 'ocr_normalizer.dart';

abstract final class ExpiryParser {
  static final _labelPattern =
      RegExp(r'VALID[ \t]*THRU|GOOD[ \t]*THRU|EXPIRES?|EXP[ \t]*DATE|MM[/\-]YY');
  static final _sincePattern = RegExp(r'MEMBER[ \t]*SINCE|VALID[ \t]*FROM');
  static final _datePattern = RegExp(
    r'(?<![0-9OQDILZSGB])([0-9OQDILZSGB]{2})[ \t]*[/\-][ \t]*'
    r'([0-9OQDILZSGB]{2,4})(?![0-9OQDILZSGB])',
  );

  static CardExpiry? parse(String text) {
    final lines = text.toUpperCase().split('\n');

    for (var i = 0; i < lines.length; i++) {
      if (!_labelPattern.hasMatch(lines[i])) continue;
      final sameLine = _latestIn(lines[i]);
      if (sameLine != null) return sameLine;
      if (i + 1 < lines.length) {
        final nextLine = _latestIn(lines[i + 1]);
        if (nextLine != null) return nextLine;
      }
    }

    final candidates = <CardExpiry>[];
    for (final line in lines) {
      if (_sincePattern.hasMatch(line)) continue;
      candidates.addAll(_allIn(line));
    }
    if (candidates.isEmpty) return null;
    candidates.sort((a, b) => a.lastMoment.compareTo(b.lastMoment));
    return candidates.last;
  }

  static CardExpiry? _latestIn(String line) {
    CardExpiry? latest;
    for (final expiry in _allIn(line)) {
      if (latest == null || expiry.lastMoment.isAfter(latest.lastMoment)) {
        latest = expiry;
      }
    }
    return latest;
  }

  static Iterable<CardExpiry> _allIn(String line) sync* {
    final currentYear = DateTime.now().year;
    for (final match in _datePattern.allMatches(line)) {
      final month = int.parse(OcrNormalizer.digits(match.group(1)!));
      final yearRaw = OcrNormalizer.digits(match.group(2)!);
      if (month < 1 || month > 12) continue;

      final int year;
      if (yearRaw.length == 2) {
        year = 2000 + int.parse(yearRaw);
      } else if (yearRaw.length == 4) {
        year = int.parse(yearRaw);
      } else {
        continue;
      }
      if (year < currentYear - 15 || year > currentYear + 20) continue;
      yield CardExpiry(month: month, year: year);
    }
  }
}
