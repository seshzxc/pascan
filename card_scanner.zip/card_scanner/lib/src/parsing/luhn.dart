abstract final class Luhn {
  static bool isValid(String digits) {
    if (digits.isEmpty) return false;
    var sum = 0;
    var double = false;
    for (var i = digits.length - 1; i >= 0; i--) {
      final code = digits.codeUnitAt(i);
      if (code < 0x30 || code > 0x39) return false;
      var value = code - 0x30;
      if (double) {
        value *= 2;
        if (value > 9) value -= 9;
      }
      sum += value;
      double = !double;
    }
    return sum % 10 == 0;
  }
}
