abstract final class OcrNormalizer {
  static const _toDigit = <String, String>{
    'O': '0',
    'Q': '0',
    'D': '0',
    'I': '1',
    'L': '1',
    'Z': '2',
    'S': '5',
    'G': '6',
    'B': '8',
  };

  static String digits(String input) =>
      input.split('').map((c) => _toDigit[c] ?? c).join();
}
