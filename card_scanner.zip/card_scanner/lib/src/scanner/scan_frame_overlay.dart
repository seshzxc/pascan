import 'package:flutter/material.dart';

class ScanFrameOverlay extends StatelessWidget {
  const ScanFrameOverlay({
    super.key,
    required this.roi,
    this.dimColor = const Color(0x99000000),
    this.borderColor = const Color(0xFFFFFFFF),
    this.borderWidth = 6,
    this.cornerRadius = 24,
  });

  final Rect roi;
  final Color dimColor;
  final Color borderColor;
  final double borderWidth;
  final double cornerRadius;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ScanFramePainter(
        roi: roi,
        dimColor: dimColor,
        borderColor: borderColor,
        borderWidth: borderWidth,
        cornerRadius: cornerRadius,
      ),
      size: Size.infinite,
    );
  }
}

class _ScanFramePainter extends CustomPainter {
  const _ScanFramePainter({
    required this.roi,
    required this.dimColor,
    required this.borderColor,
    required this.borderWidth,
    required this.cornerRadius,
  });

  final Rect roi;
  final Color dimColor;
  final Color borderColor;
  final double borderWidth;
  final double cornerRadius;

  @override
  void paint(Canvas canvas, Size size) {
    final window = Rect.fromLTRB(
      roi.left * size.width,
      roi.top * size.height,
      roi.right * size.width,
      roi.bottom * size.height,
    );
    final rounded = RRect.fromRectAndRadius(
      window,
      Radius.circular(cornerRadius),
    );
    final full = Offset.zero & size;

    canvas.saveLayer(full, Paint());
    canvas.drawRect(full, Paint()..color = dimColor);
    canvas.drawRRect(rounded, Paint()..blendMode = BlendMode.clear);
    canvas.restore();

    canvas.drawRRect(
      rounded,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = borderWidth
        ..color = borderColor,
    );
  }

  @override
  bool shouldRepaint(covariant _ScanFramePainter oldDelegate) =>
      oldDelegate.roi != roi ||
      oldDelegate.dimColor != dimColor ||
      oldDelegate.borderColor != borderColor ||
      oldDelegate.borderWidth != borderWidth ||
      oldDelegate.cornerRadius != cornerRadius;
}
