import 'dart:async';

import 'package:flutter/material.dart';

import '../models/card_scan_result.dart';
import 'card_scanner_controller.dart';
import 'messages.g.dart';

class CardScannerView extends StatefulWidget {
  const CardScannerView({
    super.key,
    required this.onScanned,
    this.onError,
    this.controller,
    this.overlay,
  });

  final ValueChanged<CardScanResult> onScanned;
  final void Function(Object error, StackTrace stackTrace)? onError;
  final CardScannerController? controller;
  final Widget? overlay;

  @override
  State<CardScannerView> createState() => _CardScannerViewState();
}

class _CardScannerViewState extends State<CardScannerView>
    with WidgetsBindingObserver {
  late final CardScannerController _controller =
      widget.controller ?? CardScannerController();
  PreviewInfo? _preview;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_start());
  }

  Future<void> _start() async {
    final CardScanResult result;
    try {
      final preview = await _controller.start();
      if (!mounted) return;
      setState(() => _preview = preview);
      result = await _controller.result;
    } catch (error, stackTrace) {
      if (!mounted) return;
      widget.onError?.call(error, stackTrace);
      return;
    }
    if (!mounted) return;
    widget.onScanned(result);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_preview == null) return;
    switch (state) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
      case AppLifecycleState.hidden:
      case AppLifecycleState.detached:
        _controller.pause().ignore();
      case AppLifecycleState.resumed:
        _controller.resume().ignore();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (widget.controller == null) unawaited(_controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final preview = _preview;
    if (preview == null) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator()),
      );
    }
    return ColoredBox(
      color: Colors.black,
      child: ClipRect(
        child: SizedBox.expand(
          child: FittedBox(
            fit: BoxFit.cover,
            clipBehavior: Clip.hardEdge,
            child: SizedBox(
              width: preview.width,
              height: preview.height,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Texture(textureId: preview.textureId),
                  if (widget.overlay != null) widget.overlay!,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
