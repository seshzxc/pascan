import 'messages.g.dart';

typedef TextHandler = void Function(String text);

class ScannerDispatcher implements ScannerFlutterApi {
  ScannerDispatcher._();

  static ScannerDispatcher? _instance;

  final _handlers = <int, TextHandler>{};

  static void register(int sessionId, TextHandler handler) {
    var dispatcher = _instance;
    if (dispatcher == null) {
      dispatcher = ScannerDispatcher._();
      _instance = dispatcher;
      ScannerFlutterApi.setUp(dispatcher);
    }
    dispatcher._handlers[sessionId] = handler;
  }

  static void unregister(int sessionId) {
    final dispatcher = _instance;
    if (dispatcher == null) return;
    dispatcher._handlers.remove(sessionId);
    if (dispatcher._handlers.isNotEmpty) return;
    ScannerFlutterApi.setUp(null);
    _instance = null;
  }

  @override
  void onRecognizedText(int sessionId, String text) {
    _handlers[sessionId]?.call(text);
  }
}
