package uz.card_scanner

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.util.Size
import android.view.Surface
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.view.TextureRegistry
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private const val MIN_SHORT_SIDE = 720
private const val TAG = "CardScanner"

class CardScannerPlugin : FlutterPlugin, ScannerHostApi {
    private class StartRequest(
        val sessionId: Long,
        callback: (Result<PreviewInfo>) -> Unit,
    ) {
        private var callback: ((Result<PreviewInfo>) -> Unit)? = callback

        fun deliver(result: Result<PreviewInfo>) {
            val pending = callback ?: return
            callback = null
            pending(result)
        }
    }

    private lateinit var context: Context
    private lateinit var textureRegistry: TextureRegistry

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)

    private var flutterApi: ScannerFlutterApi? = null
    private var textureEntry: TextureRegistry.SurfaceTextureEntry? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var boundUseCases: List<UseCase> = emptyList()
    private var lifecycleOwner: ScannerLifecycleOwner? = null
    private var pendingStart: StartRequest? = null
    @Volatile private var throttleMs = 300L
    private var lastProcessedAt = 0L
    @Volatile private var roi: ScanRoi? = null
    @Volatile private var sessionId: Long? = null
    @Volatile private var debugLogging = false
    private var loggedAnalysis = false

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        textureRegistry = binding.textureRegistry
        flutterApi = ScannerFlutterApi(binding.binaryMessenger)
        ScannerHostApi.setUp(binding.binaryMessenger, this)
    }

    override fun start(
        sessionId: Long,
        throttleMs: Long,
        roi: ScanRoi?,
        debugLogging: Boolean,
        callback: (Result<PreviewInfo>) -> Unit,
    ) {
        mainHandler.post {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED
            ) {
                callback(
                    Result.failure(
                        CardScannerFlutterError(
                            code = "no_permission",
                            message = "Camera permission is not granted",
                        )
                    )
                )
                return@post
            }

            pendingStart?.deliver(
                Result.failure(
                    CardScannerFlutterError(
                        code = "superseded",
                        message = "Scanner was restarted before the camera initialized",
                    )
                )
            )
            val request = StartRequest(sessionId, callback)
            pendingStart = request

            this.sessionId = sessionId
            this.throttleMs = throttleMs
            this.roi = roi
            this.debugLogging = debugLogging
            loggedAnalysis = false

            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                if (this.sessionId != sessionId || pendingStart !== request) {
                    request.deliver(
                        Result.failure(
                            CardScannerFlutterError(
                                code = "cancelled",
                                message = "Scanner was stopped before the camera initialized",
                            )
                        )
                    )
                    return@addListener
                }
                runCatching { future.get() }
                    .onSuccess { provider -> bind(provider, request) }
                    .onFailure {
                        pendingStart = null
                        request.deliver(Result.failure(it))
                    }
            }, ContextCompat.getMainExecutor(context))
        }
    }

    private fun bind(provider: ProcessCameraProvider, request: StartRequest) {
        runCatching {
            unbind()
            cameraProvider = provider

            val entry = textureRegistry.createSurfaceTexture()
            textureEntry = entry

            val owner = ScannerLifecycleOwner()
            lifecycleOwner = owner

            val resolutionSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1920, 1080),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                    )
                )
                .setResolutionFilter { supported, _ ->
                    val atLeastHd = supported.filter { minOf(it.width, it.height) >= MIN_SHORT_SIDE }
                    atLeastHd.ifEmpty { supported }
                }
                .build()

            val preview = Preview.Builder()
                .setResolutionSelector(resolutionSelector)
                .build()
            preview.setSurfaceProvider { surfaceRequest ->
                val resolution = surfaceRequest.resolution
                val surfaceTexture = entry.surfaceTexture()
                surfaceTexture.setDefaultBufferSize(resolution.width, resolution.height)
                val surface = Surface(surfaceTexture)
                surfaceRequest.provideSurface(surface, analysisExecutor) { surface.release() }
                surfaceRequest.setTransformationInfoListener(analysisExecutor) { info ->
                    if (debugLogging) {
                        Log.d(
                            TAG,
                            "preview buffer=" + resolution.width + "x" + resolution.height +
                                " rotationDegrees=" + info.rotationDegrees +
                                " cropRect=" + info.cropRect,
                        )
                    }
                    val upright = if (info.rotationDegrees % 180 == 0) {
                        resolution.width to resolution.height
                    } else {
                        resolution.height to resolution.width
                    }
                    mainHandler.post {
                        if (sessionId != request.sessionId) return@post
                        if (pendingStart === request) pendingStart = null
                        request.deliver(
                            Result.success(
                                PreviewInfo(
                                    textureId = entry.id(),
                                    width = upright.first.toDouble(),
                                    height = upright.second.toDouble(),
                                    rotationDegrees = 0,
                                )
                            )
                        )
                    }
                }
            }

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(analysisExecutor, ::analyze)

            val rotation = preview.targetRotation
            val landscape = rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270
            val viewPort = ViewPort.Builder(
                if (landscape) Rational(16, 9) else Rational(9, 16),
                rotation,
            ).build()
            val group = UseCaseGroup.Builder()
                .addUseCase(preview)
                .addUseCase(analysis)
                .setViewPort(viewPort)
                .build()

            owner.start()
            provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, group)
            boundUseCases = listOf(preview, analysis)
        }.onFailure {
            pendingStart = null
            request.deliver(Result.failure(it))
        }
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun analyze(imageProxy: ImageProxy) {
        val now = System.currentTimeMillis()
        val mediaImage = imageProxy.image
        if (mediaImage == null || now - lastProcessedAt < throttleMs || !busy.compareAndSet(false, true)) {
            imageProxy.close()
            return
        }
        lastProcessedAt = now

        val rotation = imageProxy.imageInfo.rotationDegrees
        val upright = if (rotation % 180 == 0) {
            imageProxy.width to imageProxy.height
        } else {
            imageProxy.height to imageProxy.width
        }

        if (debugLogging && !loggedAnalysis) {
            loggedAnalysis = true
            Log.d(
                TAG,
                "analysis buffer=" + imageProxy.width + "x" + imageProxy.height +
                    " rotationDegrees=" + rotation +
                    " upright=" + upright.first + "x" + upright.second,
            )
        }

        val image = InputImage.fromMediaImage(mediaImage, rotation)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val text = textInRoi(result, upright.first, upright.second)
                val activeSession = sessionId
                if (text.isNotEmpty() && activeSession != null) {
                    mainHandler.post {
                        flutterApi?.onRecognizedText(activeSession, text) {}
                    }
                }
            }
            .addOnCompleteListener {
                busy.set(false)
                imageProxy.close()
            }
    }

    private fun textInRoi(result: Text, uprightWidth: Int, uprightHeight: Int): String {
        val roi = this.roi ?: return result.text

        val left = roi.left * uprightWidth
        val top = roi.top * uprightHeight
        val right = roi.right * uprightWidth
        val bottom = roi.bottom * uprightHeight

        return result.textBlocks
            .flatMap { it.lines }
            .filter { line ->
                val box = line.boundingBox ?: return@filter false
                val centerX = box.exactCenterX()
                val centerY = box.exactCenterY()
                centerX >= left && centerX <= right && centerY >= top && centerY <= bottom
            }
            .joinToString("\n") { it.text }
    }

    override fun pause(sessionId: Long, callback: (Result<Unit>) -> Unit) {
        mainHandler.post {
            if (this.sessionId != sessionId) {
                callback(Result.success(Unit))
                return@post
            }
            runCatching { lifecycleOwner?.pause() }
                .onSuccess { callback(Result.success(Unit)) }
                .onFailure { callback(Result.failure(it)) }
        }
    }

    override fun resume(sessionId: Long, callback: (Result<Unit>) -> Unit) {
        mainHandler.post {
            if (this.sessionId != sessionId) {
                callback(Result.success(Unit))
                return@post
            }
            runCatching { lifecycleOwner?.start() }
                .onSuccess { callback(Result.success(Unit)) }
                .onFailure { callback(Result.failure(it)) }
        }
    }

    override fun stop(sessionId: Long, callback: (Result<Unit>) -> Unit) {
        mainHandler.post {
            if (this.sessionId != sessionId) {
                callback(Result.success(Unit))
                return@post
            }
            this.sessionId = null
            roi = null
            pendingStart?.deliver(
                Result.failure(
                    CardScannerFlutterError(
                        code = "cancelled",
                        message = "Scanner was stopped before the camera initialized",
                    )
                )
            )
            pendingStart = null
            runCatching { unbind() }
                .onSuccess { callback(Result.success(Unit)) }
                .onFailure { callback(Result.failure(it)) }
        }
    }

    private fun unbind() {
        val provider = cameraProvider
        if (provider != null && boundUseCases.isNotEmpty()) {
            provider.unbind(*boundUseCases.toTypedArray())
        }
        boundUseCases = emptyList()
        cameraProvider = null
        lifecycleOwner?.stop()
        lifecycleOwner = null
        textureEntry?.release()
        textureEntry = null
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        ScannerHostApi.setUp(binding.binaryMessenger, null)
        flutterApi = null
        mainHandler.post {
            sessionId = null
            roi = null
            pendingStart?.deliver(
                Result.failure(
                    CardScannerFlutterError(
                        code = "detached",
                        message = "Plugin was detached from the engine",
                    )
                )
            )
            pendingStart = null
            runCatching { unbind() }
            recognizer.close()
            analysisExecutor.shutdown()
        }
    }
}
